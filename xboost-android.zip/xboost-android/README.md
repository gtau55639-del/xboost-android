# XBoost — Android Game Booster (Kotlin + Jetpack Compose)

Fondasi UI terinspirasi tampilan gahar Nubia RedMagic (hex boost dial, merah-cyan,
angular, minim ikon emoji — pakai logo/vector icon). Semua data di layar Boost
dibaca **real-time dari device**, bukan animasi acak.

## Update terbaru (revisi ke-7) — Support Developer

Settings → **Support Developer**, layar baru dengan aksi real:
- **Donate** — buka link donasi (isi `DeveloperInfo.kt` dengan link Saweria/Trakteer/Ko-fi kamu sendiri)
- **Rate on Play Store** — buka listing app via `market://` intent
- **Share XBoost** — share sheet Android standar
- **Contact/Feedback** — kirim email via `mailto:` intent
- Telegram/Instagram — opsional, sembunyi otomatis kalau link dikosongin

**Penting:** semua link di `core/DeveloperInfo.kt` masih placeholder
(`support@example.com`, `saweria.co/yourname`, dst) — saya sengaja gak
ngarang link asli. Ganti sendiri sebelum publish.

**Soal atribusi:** tidak ada nama AI/assistant apapun di kode, nama app,
comment, atau README — sudah dicek ulang di seluruh project, bersih.

## Update sebelumnya (revisi ke-6) — Landscape lock + Floating Quick Panel

- **Orientasi dikunci landscape** (`android:screenOrientation="landscape"` di `MainActivity`). `LockScreenActivity` sengaja dibiarkan tidak dikunci karena dia muncul di atas app/game lain yang orientasinya bisa beda.
- **Navigasi diganti ke `NavigationRail`** (sisi kiri) — pola Material3 standar buat layar landscape, gak makan tinggi layar kayak bottom bar.
- **BoostScreen dirombak jadi 2 kolom**: kiri = hex dial + mode, kanan = monitor live + quick functions. Hex dial diperkecil biar muat di tinggi landscape phone (~360–420dp).
- **GamesScreen jadi grid 2 kolom**, **MetricsScreen** grafik RAM/CPU & Storage/Device disandingkan — manfaatin lebar landscape.
- **Fitur baru: Floating Quick Panel** (modul ke-10) — bubble merah melayang yang bisa di-drag, tap buat expand jadi toolbar mini (Trim / DND / Open / Close), nyambung ke `BoosterEngine` yang sama kayak fitur lain. Ini paling deket sama referensi gambar awal kamu (panel Basic Features/Quick Tools ala Samsung Game Booster).

## Update sebelumnya (revisi ke-5) — Settings > Modules, 9 modul pilih sendiri

Sekarang ada layar **Modules** baru (Settings → Manage Modules) — konsep "pasang
modul yang kamu mau" persis kayak modul tweak no-root. 9 modul, semuanya real:

1. **Background Trim** — kill cached background apps
2. **Game DND** — silent notifikasi saat boost
3. **Screen Awake** — layar gak mati selama XBoost dibuka
4. **Auto Game Mode** — jalanin profile per-game otomatis
5. **FPS Boost Overlay** — window FPS real di atas game (Choreographer)
6. **App Lock** — PIN-protect app pilihan (nav ke layar sendiri)
7. **High Refresh Rate (120Hz)** — lihat batasan jujurnya di bawah
8. **Thermal Guard** — suhu baterai real, warning warna saat panas
9. **Background Persistence** — exempt dari Doze biar App Lock & FPS Overlay gak gampang dibunuh OEM

### Soal modul "buka 120Hz" — jujur dari awal
Gak ada API resmi buat app pihak ketiga maksa **game lain** jalan di refresh
rate lebih tinggi tanpa root/ADB (`WRITE_SECURE_SETTINGS` gak bisa didapat app
biasa). Kalau ada booster app yang klaim bisa "unlock 120Hz di game kamu"
tanpa root, itu klaim yang gak sesuai cara kerja Android. Yang modul ini
beneran lakukan:
- Nunjukin refresh rate asli yang didukung hardware kamu
- Minta refresh rate tertinggi buat **window XBoost sendiri**
- Antar langsung ke Settings > Display, tempat kamu bisa ganti refresh rate
  sistem cuma 2 tap — itu satu-satunya cara sah tanpa root

## Update sebelumnya (revisi ke-4) — Performance Module, 3 mode beneran beda aksi

Sebelumnya Balance/Performance/Battery Save cuma label. Sekarang ketiganya
adalah **modul performa no-root** — tiap mode benar-benar mengubah setting
berbeda, real dan bisa dicek langsung di device:

| | Performance | Balance | Battery Save |
|---|---|---|---|
| Brightness | 85% (manual) | tidak diubah (adaptive) | 35% (manual) |
| Screen timeout | 120s | tidak diubah | 15s |
| Kecepatan monitor live | tiap 500ms | tiap 1000ms | tiap 3000ms |
| Trim background apps | ya, agresif | ya | **skip** (hemat baterai, karena trim sendiri makan CPU) |
| Game DND default | ON | OFF | OFF |
| Screen Awake default | ON | OFF | OFF |

Semua lewat `PerformanceModuleManager.kt` — dipicu tiap kali user pilih mode
di layar Boost, hasilnya ditampilkan apa adanya (termasuk kalau ada yang
di-skip karena izin belum di-grant), bukan pura-pura berhasil.

### Kenapa cuma segini, dan kenapa itu memang wajar
Ini **plafon jujur** yang bisa dilakukan app non-root di Android modern:
brightness & timeout (butuh izin *Modify System Settings*), agresivitas
trim background app (dibatasi OS sejak Android 8+), dan kecepatan polling
app sendiri (real, mengurangi wake-up CPU untuk proses XBoost sendiri).
XBoost **tidak** menyentuh CPU governor, GPU clock, atau RAM app lain —
itu butuh root. Efeknya nyata tapi sedang (mengurangi kontensi
background & overhead baterai), bukan overclock ajaib — sama seperti
semua "game booster no-root" lain di Play Store yang jujur soal batasannya.

## Update sebelumnya (revisi ke-3) — fitur baru
Semua real, tidak ada yang cuma UI kosong:

| Fitur | Cara kerja nyata | Izin tambahan |
|---|---|---|
| **FPS Overlay** | Window overlay + `Choreographer` vsync callback, hitung frame/detik asli | Display over other apps |
| **Game Mode Profile per-game** | Tiap game di Game Library bisa disetel DND & Screen Awake sendiri, disimpan DataStore, otomatis dipakai saat Auto Game Mode aktif | — |
| **App Lock** | PIN 4-digit (di-hash SHA-256), `LockGuardService` poll foreground app tiap 500ms via UsageStatsManager, munculin PIN screen | Display over other apps + Usage Access |
| **Accent color picker** | 4 warna (Red/Cyan/Purple/Green), berlaku ke hex dial & header lewat `CompositionLocal` | — |
| **Home screen widget** | RAM/CPU mini, `RemoteViews`, refresh instan saat di-tap | — |
| **Storage info** | `StatFs` — ruang kosong/total device asli | — |

### Batasan jujur yang perlu ditahu
- **FPS Overlay** mengukur vsync render dari proses XBoost sendiri (pendekatan yang sama dipakai semua overlay FPS non-root), bukan pembacaan langsung engine game — tidak ada API publik untuk itu tanpa root.
- **App Lock** hanya aktif selagi `LockGuardService` hidup. OEM yang agresif membunuh background service (MIUI, ColorOS, dll) bisa menghentikannya — batasan yang sama dialami semua app-locker non-root, bukan bug XBoost. Alternatif lebih andal (AccessibilityService) sengaja tidak dipakai karena minta izin privasi jauh lebih luas dari yang dibutuhkan fitur ini.
- **Widget** dibatasi Android minimal update 30 menit (`updatePeriodMillis` di-clamp OS) — makanya ada tombol refresh manual di widget-nya.
- **Accent color** baru mewarnai hex dial & header (elemen paling terlihat). Rekolor seluruh app (semua card, ikon, border) belum — itu roadmap berikutnya karena banyak layar masih pakai warna hardcoded.
- **Screenshot/Screen Record** sengaja belum dibuat — butuh `MediaProjection` yang minta izin popup tiap kali dibuka + foreground service simpan file, scope-nya beda batch.

## Update sebelumnya (revisi ke-2)
Semua kekurangan dari revisi sebelumnya sudah diperbaiki:
- ✅ **5 layar lengkap + bottom navigation**: Boost, Games, Network, Metrics, Settings
- ✅ **Permission flow**: kartu kuning muncul otomatis kalau Usage Access / Notification
  Access belum di-grant, dengan tombol yang langsung buka halaman Settings yang tepat
  (status ke-detect ulang otomatis begitu user balik ke app)
- ✅ **6 Quick Functions dipangkas dari 12 → 6, semuanya real** (tidak ada lagi tombol
  kosong `{ }`): Clear Cache, Game DND, Screen Awake, Ping Check, Power Saver, Auto Game Mode
- ✅ **State tersimpan** pakai DataStore (mode Balance/Performance/Battery, toggle fungsi,
  Auto Game Mode) — tidak reset saat app ditutup
- ✅ **Animasi hex ring pause otomatis** saat app di-background (dipantau via
  Lifecycle observer), hemat baterai
- ✅ **`SYSTEM_ALERT_WINDOW` dihapus** dari manifest karena belum ada fitur overlay
  yang memakainya — menghindari red flag review Play Store
- ✅ Layar **Games** menampilkan game yang **benar-benar terinstall** di device (bukan
  daftar statis), layar **Metrics** punya grafik RAM/CPU real 40 detik terakhir +
  info baterai/uptime asli, layar **Network** punya tes ping real yang bisa di-refresh

## Cara build
1. Buka folder ini di Android Studio (Koala/Ladybug ke atas).
2. Biarkan Gradle sync otomatis (butuh koneksi internet untuk download dependency).
3. Run ke device/emulator (`minSdk 26` / Android 8.0+).
4. Untuk APK release: `Build > Generate Signed App Bundle / APK`.

## Fungsi yang REAL dan langsung jalan
| Fitur | Cara kerja | File |
|---|---|---|
| RAM live | `ActivityManager.MemoryInfo`, publik, tanpa izin khusus | `SystemMonitor.kt` |
| CPU live | Baca `/proc/stat` 2x lalu hitung delta | `SystemMonitor.kt` |
| Ping live | Cek latency ke `8.8.8.8` | `SystemMonitor.kt` |
| Clear/trim background apps | `ActivityManager.killBackgroundProcesses()` per app | `BoosterEngine.kt` |
| Game DND | `NotificationManager.setInterruptionFilter()` | `BoosterEngine.kt` |
| Deteksi game di foreground | `UsageStatsManager` | `BoosterEngine.kt` |

## Izin yang HARUS di-grant manual oleh user (batasan OS Android, bukan bug)
- **Usage access** (buat deteksi game aktif) → user diarahkan ke
  `Settings > Apps > Special access > Usage access`.
- **Notification access** (buat Game DND) → `Settings > Apps > Special access > Notification access`.
- Android **tidak mengizinkan** aplikasi pihak ketiga memberi izin ini ke diri
  sendiri secara otomatis — ini proteksi sistem, semua booster app resmi di
  Play Store juga wajib lewat alur yang sama.

## Yang TIDAK dimasukkan karena secara teknis tidak mungkin tanpa root
- Overclock/underclock CPU-GPU sungguhan
- Memaksa "membebaskan" RAM milik app lain
- Ubah CPU governor / thermal profile pabrik

Kalau ada app booster yang klaim bisa itu tanpa root, itu tampilan palsu
(placebo UI) — bukan sesuatu yang OS Android izinkan sejak sandboxing ketat
diberlakukan (Android 8+). Jujur soal ini penting supaya XBoost tidak jadi
app "bohong" seperti kebanyakan game booster di Play Store.

## Struktur project
```
xboost-android/
  app/src/main/java/com/xboost/app/
    MainActivity.kt
    core/SystemMonitor.kt       # baca RAM/CPU/ping/storage real
    core/BoosterEngine.kt       # aksi boost real
    core/PermissionManager.kt   # cek status izin real + deep-link ke Settings
    core/PreferencesManager.kt  # DataStore: mode, toggle, profile per-game, accent, PIN
    overlay/FpsOverlayService.kt   # window overlay real, ukur FPS via Choreographer
    lock/PinHasher.kt              # hash PIN, sesi unlock
    lock/LockGuardService.kt       # poll foreground app, trigger lock screen
    lock/LockScreenActivity.kt     # UI PIN full-screen
    widget/XBoostWidgetProvider.kt # widget homescreen RAM/CPU
    core/DisplayRefreshManager.kt  # info refresh rate real + request untuk window sendiri
    core/ThermalGuardManager.kt    # baca suhu baterai real
    ui/theme/                   # warna, tipografi, LocalAccent (CompositionLocal)
    ui/nav/XBoostNav.kt         # bottom navigation, 5 destinasi + route modules/app_lock
    ui/screens/
      BoostScreen.kt      # hex dial, gauge live, permission card, quick functions, 3-mode module
      GamesScreen.kt      # game terinstall + profile DND/Screen Awake per game
      NetworkScreen.kt    # ping test real
      MetricsScreen.kt    # grafik RAM/CPU 40 detik + storage + info device
      SettingsScreen.kt   # izin, accent picker, entry ke Modules
      ModulesScreen.kt    # 9 modul pilih sendiri
      AppLockScreen.kt    # set PIN, pilih app, nyalain lock guard service
```

## Langkah lanjutan yang disarankan
1. Ganti font sistem dengan Rajdhani/Chakra Petch (taruh `.ttf` di `res/font/`)
   supaya persis referensi visual.
2. Tambah layar Games/Network/Metrics/Settings (skeleton belum dibuat di sini
   biar project tetap ringkas — pola sudah ada di `BoostScreen.kt` untuk ditiru).
3. Kalau target-nya ekspor ke Play Store: pastikan deskripsi listing tidak
   mengklaim "overclock" atau "boost RAM app lain" — itu melanggar kebijakan
   Google Play soal klaim performa yang tidak bisa dibuktikan.

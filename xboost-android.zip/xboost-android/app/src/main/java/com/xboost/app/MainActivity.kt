package com.xboost.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.xboost.app.core.AccentColor
import com.xboost.app.core.PreferencesManager
import com.xboost.app.ui.nav.XBoostApp
import com.xboost.app.ui.theme.XBoostTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val accent by PreferencesManager.accentColor(this).collectAsState(initial = AccentColor.RED)
            XBoostTheme(accent = accent) {
                XBoostApp()
            }
        }
    }
}

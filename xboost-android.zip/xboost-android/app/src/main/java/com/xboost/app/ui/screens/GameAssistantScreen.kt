package com.xboost.app.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xboost.app.core.BoosterEngine
import com.xboost.app.core.GameContentRepository
import com.xboost.app.ui.theme.*
import java.util.Locale

private enum class AssistantTab { AI_TIPS, GUIDE }

private data class ChatLine(val fromUser: Boolean, val text: String)

/**
 * Two tabs:
 *  - AI Tips: a chat-style box where the user types a question and gets back
 *    the closest matching curated tip. Purely offline keyword lookup — this
 *    label is honest about what it is, same philosophy as the rest of XBoost.
 *  - Guide: always-visible structured tips for the selected game.
 *
 * Neither tab reads game memory, injects input, or automates play in any
 * way — that's out of scope for XBoost by design (see README).
 */
@Composable
fun GameAssistantScreen(pkg: String, onBack: () -> Unit) {
    val gameName = BoosterEngine.KNOWN_GAMES[pkg] ?: "This game"
    var tab by remember { mutableStateOf(AssistantTab.AI_TIPS) }

    Column(modifier = Modifier.fillMaxSize().background(Bg0).padding(horizontal = 20.dp, vertical = 20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Text1, modifier = Modifier.clickable { onBack() })
            Spacer(Modifier.width(10.dp))
            Column {
                Text("GAME MODULES", color = Text2, fontSize = 10.sp, letterSpacing = 1.sp)
                Text(gameName, color = Text0, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
        }
        Spacer(Modifier.height(14.dp))

        TabRow(
            selectedTabIndex = tab.ordinal,
            containerColor = Bg1,
            contentColor = XCyan,
            indicator = { positions ->
                TabRowDefaults.SecondaryIndicator(
                    Modifier.tabIndicatorOffset(positions[tab.ordinal]),
                    color = XCyan
                )
            }
        ) {
            Tab(selected = tab == AssistantTab.AI_TIPS, onClick = { tab = AssistantTab.AI_TIPS }) {
                Row(modifier = Modifier.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.SmartToy, contentDescription = null, tint = if (tab == AssistantTab.AI_TIPS) XCyan else Text2, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("AI Tips", color = if (tab == AssistantTab.AI_TIPS) XCyan else Text2, fontSize = 12.sp)
                }
            }
            Tab(selected = tab == AssistantTab.GUIDE, onClick = { tab = AssistantTab.GUIDE }) {
                Row(modifier = Modifier.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.MenuBook, contentDescription = null, tint = if (tab == AssistantTab.GUIDE) XCyan else Text2, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Guide", color = if (tab == AssistantTab.GUIDE) XCyan else Text2, fontSize = 12.sp)
                }
            }
        }
        Spacer(Modifier.height(14.dp))

        when (tab) {
            AssistantTab.AI_TIPS -> AiTipsTab(pkg)
            AssistantTab.GUIDE -> GuideTab(pkg)
        }
    }
}

@Composable
private fun AiTipsTab(pkg: String) {
    val context = LocalContext.current
    var input by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<ChatLine>() }
    val suggestions = remember(pkg) { GameContentRepository.suggestedQuestions(pkg) }

    fun ask(question: String) {
        if (question.isBlank()) return
        val ans = GameContentRepository.answer(pkg, question)
        messages.add(ChatLine(fromUser = true, text = question))
        messages.add(
            ChatLine(
                fromUser = false,
                text = ans ?: "Belum ada tips spesifik untuk itu di database offline XBoost — coba tab Guide buat tips umum."
            )
        )
        input = ""
    }

    // Voice input: hands off to the system speech recognizer (Google app or
    // OEM equivalent) via the standard RECOGNIZE_SPEECH intent — XBoost never
    // records audio itself, so no RECORD_AUDIO permission is needed here.
    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!spoken.isNullOrBlank()) ask(spoken)
        }
    }

    fun launchVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toString())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Tanya XBoost…")
        }
        // resolveActivity requires the <queries> entry in AndroidManifest.xml on
        // Android 11+ (package visibility) — without it this silently returns null
        // even when a speech recognizer IS installed.
        if (intent.resolveActivity(context.packageManager) != null) {
            runCatching { speechLauncher.launch(intent) }
                .onFailure { Toast.makeText(context, "Gak bisa buka voice input di device ini", Toast.LENGTH_SHORT).show() }
        } else {
            Toast.makeText(context, "Voice input gak tersedia — device ini gak punya speech recognizer terpasang", Toast.LENGTH_SHORT).show()
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            "Offline tips lookup — matches your question to curated tips on-device. Not a cloud AI, " +
            "and it never plays, aims, or automates anything in the game for you.",
            color = Text2, fontSize = 10.sp, lineHeight = 14.sp, modifier = Modifier.padding(bottom = 10.dp)
        )

        if (messages.isEmpty()) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 10.dp)) {
                suggestions.forEach { s ->
                    SuggestionChip(
                        onClick = { ask(s) },
                        label = { Text(s, fontSize = 10.sp) },
                        colors = SuggestionChipDefaults.suggestionChipColors(containerColor = Panel, labelColor = XCyan)
                    )
                }
            }
        }

        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages) { line -> ChatBubble(line) }
        }

        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ketik atau tap mic…", fontSize = 12.sp) },
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp, color = Text0),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = XCyan, unfocusedBorderColor = Line,
                    focusedTextColor = Text0, unfocusedTextColor = Text0
                )
            )
            Spacer(Modifier.width(8.dp))
            IconButton(
                onClick = { launchVoiceInput() },
                modifier = Modifier.background(Panel, RoundedCornerShape(10.dp))
            ) {
                Icon(Icons.Filled.Mic, contentDescription = "Voice input", tint = XCyan)
            }
            Spacer(Modifier.width(6.dp))
            IconButton(
                onClick = { ask(input.trim()) },
                modifier = Modifier.background(XCyanDim, RoundedCornerShape(10.dp))
            ) {
                Icon(Icons.Filled.Send, contentDescription = "Send", tint = XCyan)
            }
        }
    }
}

@Composable
private fun ChatBubble(line: ChatLine) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (line.fromUser) Arrangement.End else Arrangement.Start
    ) {
        Column(
            modifier = Modifier
                .background(if (line.fromUser) XCyanDim else Panel, RoundedCornerShape(12.dp))
                .border(1.dp, if (line.fromUser) XCyan.copy(alpha = 0.4f) else Line, RoundedCornerShape(12.dp))
                .widthIn(max = 260.dp)
                .padding(10.dp)
        ) {
            if (!line.fromUser) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 3.dp)) {
                    Icon(Icons.Filled.SmartToy, contentDescription = null, tint = XCyan, modifier = Modifier.size(12.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("XBoost Tips", color = XCyan, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            Text(line.text, color = Text0, fontSize = 12.sp, lineHeight = 16.sp)
        }
    }
}

@Composable
private fun GuideTab(pkg: String) {
    val sections = remember(pkg) { GameContentRepository.guideFor(pkg) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(sections) { section ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Panel, RoundedCornerShape(14.dp))
                    .border(1.dp, Line, RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.MenuBook, contentDescription = null, tint = XCyan, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(section.heading, color = Text0, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }
                Spacer(Modifier.height(8.dp))
                section.points.forEach { point ->
                    Row(modifier = Modifier.padding(bottom = 6.dp)) {
                        Text("•  ", color = XCyan, fontSize = 12.sp)
                        Text(point, color = Text1, fontSize = 12.sp, lineHeight = 16.sp)
                    }
                }
            }
        }
    }
}

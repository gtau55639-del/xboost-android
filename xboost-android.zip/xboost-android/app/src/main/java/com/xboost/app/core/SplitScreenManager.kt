package com.xboost.app.core

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast

/**
 * Real, honest split-screen / dual-app helper — no root, no hidden APIs,
 * no accessibility-service gesture faking.
 *
 * What Android actually allows a normal app to do here:
 * - `Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT` tells the system "put this new
 *   activity in the *other* split-screen pane" — but it only has any effect
 *   once the device is ALREADY in multi-window/split-screen mode. There is
 *   no public, non-root API that lets a third-party app force the device
 *   INTO split-screen from scratch; Google restricts that on purpose so
 *   apps can't hijack the screen. Any booster app that claims otherwise is
 *   either using unstable hidden APIs (breaks across OEM/Android versions,
 *   commonly rejected or unstable on Play builds) or is exaggerating.
 * - So XBoost's job is the part that's real: launch App A, tell the user in
 *   one tap how to actually enter split view (Recents → app icon → Split
 *   screen — the official OS gesture on Android 7+), then launch App B with
 *   the adjacent flag so it lands in the second pane instead of covering
 *   App A.
 */
object SplitScreenManager {

    /** True on Android N+ where split-screen / multi-window exists at all. */
    fun isSupported(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N

    /**
     * Launches [pkgA] normally, then — after a short delay the caller controls —
     * launches [pkgB] with FLAG_ACTIVITY_LAUNCH_ADJACENT so it takes the second
     * pane if (and only if) the device is already showing split screen.
     * Returns false if either package has no launchable activity.
     */
    fun launchPrimary(context: Context, pkg: String): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }

    fun launchAdjacent(context: Context, pkg: String): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            intent.addFlags(Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)
        }
        val options = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            ActivityOptions.makeBasic().toBundle()
        } else null
        context.startActivity(intent, options)
        return true
    }

    /**
     * The one-tap "Launch Split" action used by both the Split Screen screen
     * and the floating panel: opens App A, then App B adjacent. If the device
     * isn't already in split view this simply opens both apps one after the
     * other (App B on top) — never a silent no-op, and never a fake "success".
     */
    fun launchPair(context: Context, pkgA: String, pkgB: String) {
        val okA = launchPrimary(context, pkgA)
        val okB = launchAdjacent(context, pkgB)
        if (!okA || !okB) {
            Toast.makeText(context, "One of the selected apps couldn't be opened", Toast.LENGTH_SHORT).show()
        }
    }

    fun label(context: Context, pkg: String): String =
        runCatching {
            val ai = context.packageManager.getApplicationInfo(pkg, 0)
            context.packageManager.getApplicationLabel(ai).toString()
        }.getOrDefault(pkg)
}

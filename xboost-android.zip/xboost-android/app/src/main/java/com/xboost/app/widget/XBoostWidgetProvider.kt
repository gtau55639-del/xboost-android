package com.xboost.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.xboost.app.MainActivity
import com.xboost.app.R
import com.xboost.app.core.SystemMonitor

/**
 * Honest constraint: Android enforces a minimum auto-update interval of
 * ~30 minutes for app widgets (updatePeriodMillis is clamped by the OS,
 * regardless of what a lower value requests). That's a system limit, not
 * something this app can bypass without a foreground service running
 * permanently just for the widget — not worth the battery cost for a
 * home-screen glance. Tapping the widget forces an instant real refresh.
 */
class XBoostWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id -> updateWidget(context, manager, id) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, XBoostWidgetProvider::class.java))
            ids.forEach { id -> updateWidget(context, manager, id) }
        }
    }

    private fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
        val ram = SystemMonitor.getRamInfo(context)
        val cpu = SystemMonitor.cpuUsagePercent()

        val views = RemoteViews(context.packageName, R.layout.widget_xboost).apply {
            setTextViewText(R.id.widget_ram_value, "${ram.percentUsed}%")
            setTextViewText(R.id.widget_cpu_value, cpu?.let { "$it%" } ?: "N/A")

            val refreshIntent = Intent(context, XBoostWidgetProvider::class.java).apply { action = ACTION_REFRESH }
            val refreshPending = PendingIntent.getBroadcast(
                context, widgetId, refreshIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            setOnClickPendingIntent(R.id.widget_title, refreshPending)

            val openIntent = PendingIntent.getActivity(
                context, widgetId, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            setOnClickPendingIntent(R.id.widget_ram_value, openIntent)
            setOnClickPendingIntent(R.id.widget_cpu_value, openIntent)
        }
        manager.updateAppWidget(widgetId, views)
    }

    companion object {
        private const val ACTION_REFRESH = "com.xboost.app.widget.ACTION_REFRESH"
    }
}

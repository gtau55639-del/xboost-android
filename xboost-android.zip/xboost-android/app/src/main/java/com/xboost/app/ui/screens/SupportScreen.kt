package com.xboost.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xboost.app.core.DeveloperInfo
import com.xboost.app.core.SupportManager
import com.xboost.app.ui.theme.*

@Composable
fun SupportScreen(onBack: () -> Unit) {
    val context = LocalContext.current

    Column(
        modifier = Modifier.fillMaxSize().background(Bg0).verticalScrollFix().padding(horizontal = 20.dp, vertical = 24.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Text1, modifier = Modifier.clickable { onBack() })
            Spacer(Modifier.width(10.dp))
            Text("SUPPORT DEVELOPER", color = Text0, fontWeight = FontWeight.Bold, fontSize = 19.sp)
        }
        Text(
            "XBoost is built and maintained independently. If it's useful, these help keep it going.",
            color = Text2, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
        )

        SupportRow(
            icon = Icons.Filled.Favorite, tint = XRed,
            title = "Donate", desc = "Support development directly"
        ) { SupportManager.openUrl(context, DeveloperInfo.DONATION_URL) }

        Spacer(Modifier.height(10.dp))
        SupportRow(
            icon = Icons.Filled.Star, tint = XAmber,
            title = "Rate on Play Store", desc = "A quick rating helps a lot"
        ) { SupportManager.openPlayStoreListing(context) }

        Spacer(Modifier.height(10.dp))
        SupportRow(
            icon = Icons.Filled.Share, tint = XCyan,
            title = "Share XBoost", desc = "Tell a friend who games on the same phone as you"
        ) { SupportManager.shareApp(context) }

        Spacer(Modifier.height(10.dp))
        SupportRow(
            icon = Icons.Filled.Email, tint = Text1,
            title = "Contact / Feedback", desc = DeveloperInfo.SUPPORT_EMAIL
        ) { SupportManager.sendSupportEmail(context) }

        if (DeveloperInfo.TELEGRAM_URL.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            SupportRow(icon = Icons.Filled.Send, tint = XCyan, title = "Telegram", desc = "Updates & community") {
                SupportManager.openUrl(context, DeveloperInfo.TELEGRAM_URL)
            }
        }
        if (DeveloperInfo.INSTAGRAM_URL.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            SupportRow(icon = Icons.Filled.CameraAlt, tint = XRed, title = "Instagram", desc = "Behind the scenes") {
                SupportManager.openUrl(context, DeveloperInfo.INSTAGRAM_URL)
            }
        }

        Spacer(Modifier.height(24.dp))
        Column(
            modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp)).padding(16.dp)
        ) {
            Text("Made by ${DeveloperInfo.DEVELOPER_NAME}", color = Text0, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(
                "Every stat and action in XBoost reflects real device state — no placebo numbers, no overclocking claims.",
                color = Text2, fontSize = 10.sp, lineHeight = 14.sp, modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
private fun Modifier.verticalScrollFix(): Modifier {
    val scrollState = androidx.compose.foundation.rememberScrollState()
    return this.then(androidx.compose.foundation.verticalScroll(scrollState))
}

@Composable
private fun SupportRow(icon: ImageVector, tint: androidx.compose.ui.graphics.Color, title: String, desc: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Panel, RoundedCornerShape(14.dp))
            .border(1.dp, Line, RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Text0, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(desc, color = Text2, fontSize = 10.sp)
        }
        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = Text2)
    }
}

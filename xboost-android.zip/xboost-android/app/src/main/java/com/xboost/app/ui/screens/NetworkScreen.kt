package com.xboost.app.ui.screens

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xboost.app.core.SystemMonitor
import com.xboost.app.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun NetworkScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pingResult by remember { mutableStateOf<Long?>(null) }
    var testing by remember { mutableStateOf(false) }

    val connectionType = remember { connectionTypeLabel(context) }

    Column(
        modifier = Modifier.fillMaxSize().background(Bg0).padding(horizontal = 20.dp, vertical = 24.dp)
    ) {
        Text("NETWORK", color = Text0, fontWeight = FontWeight.Bold, fontSize = 19.sp)
        Text("Real latency test, no simulated numbers", color = Text2, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp, bottom = 18.dp))

        Row(
            modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp)).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Wifi, contentDescription = null, tint = XCyan, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Connection", color = Text1, fontSize = 11.sp)
                Text(connectionType, color = Text0, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            }
        }

        Spacer(Modifier.height(14.dp))

        Column(
            modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp)).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Filled.NetworkCheck, contentDescription = null, tint = if (testing) XAmber else XCyan, modifier = Modifier.size(32.dp))
            Spacer(Modifier.height(10.dp))
            Text(
                text = when {
                    testing -> "Testing…"
                    pingResult != null -> "${pingResult} ms"
                    else -> "—"
                },
                color = Text0, fontWeight = FontWeight.Bold, fontSize = 26.sp
            )
            Text("Latency to 8.8.8.8", color = Text2, fontSize = 10.sp)
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = {
                    testing = true
                    scope.launch {
                        pingResult = SystemMonitor.pingMs()
                        testing = false
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = XRed),
                enabled = !testing
            ) {
                Text(if (testing) "TESTING" else "RUN TEST")
            }
        }
    }
}

private fun connectionTypeLabel(context: Context): String {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return "Unknown"
    val network = cm.activeNetwork ?: return "Disconnected"
    val caps = cm.getNetworkCapabilities(network) ?: return "Unknown"
    return when {
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile Data"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
        else -> "Unknown"
    }
}

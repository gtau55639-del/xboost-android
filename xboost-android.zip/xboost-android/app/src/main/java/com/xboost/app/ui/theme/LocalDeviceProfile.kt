package com.xboost.app.ui.theme

import androidx.compose.runtime.staticCompositionLocalOf
import com.xboost.app.core.DeviceProfile
import com.xboost.app.core.DeviceTier

/**
 * Real device RAM tier (LOW ~1-3GB / MID ~3-6GB / HIGH 6GB+, see
 * DeviceCompat.classify) made available to any Compose screen so visuals
 * that cost real CPU per frame — infinite rotation animations, extra
 * decorative draw passes — scale DOWN on a 1-2GB budget phone instead of
 * competing with the game XBoost is meant to be boosting. On a 8-12GB
 * flagship every effect still runs at full detail; nothing is removed
 * there, only added-back on the low end.
 *
 * Default matches DeviceCompat's own safe fallback (MID) so a screen that
 * forgets to read the real profile fails toward "balanced", never toward
 * "assume flagship hardware".
 */
val LocalDeviceProfile = staticCompositionLocalOf {
    DeviceProfile(
        tier = DeviceTier.MID,
        isLowRamDevice = false,
        totalRamMb = 0L,
        sdkInt = android.os.Build.VERSION.SDK_INT,
        pollingFloorMs = 800L
    )
}

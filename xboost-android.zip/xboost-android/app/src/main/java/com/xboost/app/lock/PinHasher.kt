package com.xboost.app.lock

import java.security.MessageDigest

object PinHasher {
    fun hash(pin: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun matches(pin: String, storedHash: String): Boolean = hash(pin) == storedHash
}

/**
 * Tracks which locked apps have already been unlocked in the current
 * "session" so the PIN screen doesn't re-appear every single time
 * UsageStatsManager reports the same foreground app during polling.
 * Cleared when the app leaves the foreground (real signal: a different,
 * non-locked package becomes foreground) or the guard service restarts.
 */
object UnlockSession {
    private val unlockedUntilLeft = mutableSetOf<String>()

    fun isUnlocked(pkg: String): Boolean = unlockedUntilLeft.contains(pkg)
    fun markUnlocked(pkg: String) { unlockedUntilLeft.add(pkg) }
    fun onForegroundChanged(currentPkg: String?) {
        // Once the user leaves a locked app, forget the unlock so it locks again next time.
        unlockedUntilLeft.retainAll(setOfNotNull(currentPkg))
    }
}

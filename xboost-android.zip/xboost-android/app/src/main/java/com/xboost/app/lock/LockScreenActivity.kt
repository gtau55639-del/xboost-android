package com.xboost.app.lock

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xboost.app.core.PreferencesManager
import com.xboost.app.ui.theme.*
import kotlinx.coroutines.flow.first

class LockScreenActivity : ComponentActivity() {

    companion object {
        const val EXTRA_TARGET_PKG = "target_pkg"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val targetPkg = intent.getStringExtra(EXTRA_TARGET_PKG)

        setContent {
            XBoostTheme {
                var input by remember { mutableStateOf("") }
                var error by remember { mutableStateOf(false) }
                var storedHash by remember { mutableStateOf<String?>(null) }

                LaunchedEffect(Unit) {
                    storedHash = PreferencesManager.lockPinHash(this@LockScreenActivity).first()
                }

                Column(
                    modifier = Modifier.fillMaxSize().background(Bg0).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Filled.Lock, contentDescription = null, tint = XRed, modifier = Modifier.size(40.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("App Locked", color = Text0, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Enter your PIN to continue", color = Text2, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp, bottom = 24.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        repeat(4) { i ->
                            Box(
                                modifier = Modifier
                                    .size(16.dp)
                                    .background(if (i < input.length) XCyan else Panel, CircleShape)
                            )
                        }
                    }
                    if (error) {
                        Text("Wrong PIN", color = XRed, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
                    }

                    Spacer(Modifier.height(28.dp))
                    Keypad(
                        onDigit = { d ->
                            if (input.length < 4) {
                                input += d
                                error = false
                                if (input.length == 4) {
                                    val hash = storedHash
                                    if (hash != null && PinHasher.matches(input, hash)) {
                                        targetPkg?.let { UnlockSession.markUnlocked(it) }
                                        finish()
                                    } else {
                                        error = true
                                        input = ""
                                    }
                                }
                            }
                        },
                        onBackspace = { if (input.isNotEmpty()) input = input.dropLast(1) }
                    )
                }
            }
        }
    }

    override fun onBackPressed() {
        // Deliberately does nothing extra beyond default behavior — sending
        // the user home instead of back into the locked app is handled by
        // the OS back-stack naturally since this activity has no parent link.
        super.onBackPressed()
    }
}

@Composable
private fun Keypad(onDigit: (String) -> Unit, onBackspace: () -> Unit) {
    val rows = listOf(
        listOf("1", "2", "3"),
        listOf("4", "5", "6"),
        listOf("7", "8", "9"),
        listOf("", "0", "⌫")
    )
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                row.forEach { key ->
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .background(if (key.isNotEmpty()) Panel else Color.Transparent, CircleShape)
                            .then(
                                if (key.isNotEmpty()) Modifier.clickable {
                                    if (key == "⌫") onBackspace() else onDigit(key)
                                } else Modifier
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (key.isNotEmpty()) Text(key, color = Text0, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}

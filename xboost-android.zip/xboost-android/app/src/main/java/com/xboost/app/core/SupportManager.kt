package com.xboost.app.core

import android.content.Context
import android.content.Intent
import android.net.Uri

object SupportManager {

    fun openUrl(context: Context, url: String) {
        if (url.isBlank()) return
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        runCatching { context.startActivity(intent) }
    }

    fun sendSupportEmail(context: Context, subject: String = "XBoost feedback") {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:${DeveloperInfo.SUPPORT_EMAIL}")
            putExtra(Intent.EXTRA_SUBJECT, subject)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        runCatching { context.startActivity(intent) }
    }

    /** Opens the Play Store app if installed, falls back to the web listing. */
    fun openPlayStoreListing(context: Context) {
        val pkg = context.packageName
        val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        val result = runCatching { context.startActivity(marketIntent) }
        if (result.isFailure) {
            openUrl(context, "https://play.google.com/store/apps/details?id=$pkg")
        }
    }

    fun shareApp(context: Context) {
        val pkg = context.packageName
        val text = "Cek XBoost — modul performa & game booster no-root: " +
            "https://play.google.com/store/apps/details?id=$pkg"
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        runCatching { context.startActivity(Intent.createChooser(intent, "Share XBoost").apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }) }
    }
}

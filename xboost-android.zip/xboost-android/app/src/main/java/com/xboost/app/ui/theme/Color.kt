package com.xboost.app.ui.theme

import androidx.compose.ui.graphics.Color

val Bg0 = Color(0xFF07070B)
val Bg1 = Color(0xFF0D0E15)
val Panel = Color(0xFF15161F)
val Line = Color(0xFF23242F)

val XRed = Color(0xFFFF2B45)
val XRedDim = Color(0x33FF2B45)
val XCyan = Color(0xFF26F0D0)
val XCyanDim = Color(0x3326F0D0)
val XAmber = Color(0xFFFFB020)

val Text0 = Color(0xFFF2F3F7)
val Text1 = Color(0xFF9497A8)
val Text2 = Color(0xFF5C5F70)

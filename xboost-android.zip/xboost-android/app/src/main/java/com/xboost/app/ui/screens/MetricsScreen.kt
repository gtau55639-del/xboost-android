package com.xboost.app.ui.screens

import android.content.Context
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xboost.app.core.SystemMonitor
import com.xboost.app.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun MetricsScreen() {
    val context = LocalContext.current
    val ramHistory = remember { mutableStateListOf<Int>() }
    val cpuHistory = remember { mutableStateListOf<Int>() }

    LaunchedEffect(Unit) {
        while (true) {
            val ram = SystemMonitor.getRamInfo(context)
            val cpu = SystemMonitor.cpuUsagePercent() ?: 0
            ramHistory.add(ram.percentUsed)
            cpuHistory.add(cpu)
            if (ramHistory.size > 40) ramHistory.removeAt(0)
            if (cpuHistory.size > 40) cpuHistory.removeAt(0)
            delay(1000)
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Bg0).padding(horizontal = 20.dp, vertical = 24.dp)
    ) {
        Text("METRICS", color = Text0, fontWeight = FontWeight.Bold, fontSize = 19.sp)
        Text("Rolling 40-second live history, sampled every second", color = Text2, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp, bottom = 18.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            Box(modifier = Modifier.weight(1f)) { MetricGraphCard("RAM usage", ramHistory, XRed) }
            Box(modifier = Modifier.weight(1f)) { MetricGraphCard("CPU usage", cpuHistory, XCyan) }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            Box(modifier = Modifier.weight(1f)) { StorageCard() }
            Box(modifier = Modifier.weight(1f)) { DeviceInfoCard(context) }
        }
    }
}

@Composable
private fun StorageCard() {
    val stat = remember { StatFs(Environment.getDataDirectory().path) }
    val totalGb = (stat.totalBytes / (1024.0 * 1024 * 1024))
    val freeGb = (stat.availableBytes / (1024.0 * 1024 * 1024))
    val usedPercent = (((totalGb - freeGb) / totalGb) * 100).toInt().coerceIn(0, 100)

    Column(
        modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp)).padding(16.dp)
    ) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("Storage", color = Text0, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text("$usedPercent% used", color = XAmber, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "%.1f GB free of %.1f GB".format(freeGb, totalGb),
            color = Text2, fontSize = 11.sp
        )
    }
}

@Composable
private fun MetricGraphCard(title: String, history: List<Int>, color: androidx.compose.ui.graphics.Color) {
    Column(
        modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp)).padding(16.dp)
    ) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text(title, color = Text0, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text("${history.lastOrNull() ?: 0}%", color = color, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        Spacer(Modifier.height(10.dp))
        Canvas(modifier = Modifier.fillMaxWidth().height(70.dp)) {
            if (history.size < 2) return@Canvas
            val stepX = size.width / (40 - 1).toFloat()
            val path = Path()
            history.forEachIndexed { i, v ->
                val x = i * stepX
                val y = size.height - (v / 100f) * size.height
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, color = color, style = Stroke(width = 2.dp.toPx()))
        }
    }
}

@Composable
private fun DeviceInfoCard(context: Context) {
    val batteryPct = remember { batteryPercent(context) }
    val uptime = remember { uptimeString() }

    Column(
        modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp)).padding(16.dp)
    ) {
        Text("DEVICE", color = Text1, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        InfoRow("Battery", "$batteryPct%")
        InfoRow("Device uptime", uptime)
        InfoRow("Android version", android.os.Build.VERSION.RELEASE)
        InfoRow("Model", "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Text2, fontSize = 12.sp)
        Text(value, color = Text0, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

private fun batteryPercent(context: Context): Int {
    val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
}

private fun uptimeString(): String {
    val ms = SystemClock.elapsedRealtime()
    val hours = ms / (1000 * 60 * 60)
    val minutes = (ms / (1000 * 60)) % 60
    return "${hours}h ${minutes}m"
}

package com.xboost.app.core

import android.content.Context
import android.provider.Settings

/**
 * XBoost's "no-root performance module". This is the honest ceiling of what
 * a third-party Android app can change system-wide without root:
 *  - screen brightness & timeout (needs WRITE_SETTINGS, user-granted)
 *  - how aggressively it asks the OS to trim cached background apps
 *  - how often it polls/wakes itself to refresh live stats
 *  - sane defaults for Game DND / Keep Screen Awake
 *
 * It does NOT touch CPU governor, GPU clocks, or another app's memory —
 * those require root and are intentionally out of scope. Framed honestly:
 * this measurably reduces background contention and trims idle battery/CPU
 * overhead, it does not "unlock" hardware performance.
 */
data class PerformanceProfile(
    val mode: BoostMode,
    val label: String,
    val brightnessPercent: Int?,      // null = don't touch
    val restoreAutoBrightness: Boolean,
    val screenTimeoutSeconds: Int?,   // null = don't touch
    val pollingIntervalMs: Long,      // how often the Boost screen refreshes live stats
    val trimBackground: Boolean,
    val autoGameDndDefault: Boolean,
    val keepScreenOnDefault: Boolean
)

data class ModuleApplyResult(val profile: PerformanceProfile, val changes: List<String>) {
    val summary: String get() = "${profile.label}: " + changes.joinToString(" · ")
}

object PerformanceModuleManager {

    fun profileFor(mode: BoostMode): PerformanceProfile = when (mode) {
        BoostMode.PERFORMANCE -> PerformanceProfile(
            mode = mode, label = "Performance",
            // 85% was too aggressive — display backlight is one of the biggest heat
            // contributors during long sessions. 70% keeps it clearly brighter than
            // Balance while noticeably reducing sustained heat buildup.
            brightnessPercent = 70, restoreAutoBrightness = false,
            screenTimeoutSeconds = 120,
            pollingIntervalMs = 500,
            trimBackground = true,
            autoGameDndDefault = true,
            keepScreenOnDefault = true
        )
        BoostMode.BATTERY_SAVE -> PerformanceProfile(
            mode = mode, label = "Battery Save",
            brightnessPercent = 35, restoreAutoBrightness = false,
            screenTimeoutSeconds = 15,
            pollingIntervalMs = 3000,
            trimBackground = false, // trimming itself burns a few CPU cycles; skip it to save power
            autoGameDndDefault = false,
            keepScreenOnDefault = false
        )
        BoostMode.BALANCE -> PerformanceProfile(
            mode = mode, label = "Balance",
            brightnessPercent = null, restoreAutoBrightness = true,
            screenTimeoutSeconds = null,
            pollingIntervalMs = 1000,
            trimBackground = true,
            autoGameDndDefault = false,
            keepScreenOnDefault = false
        )
    }

    /**
     * Applies the profile's real, verifiable effects and returns exactly
     * what happened — including what was skipped and why, so the UI never
     * claims a change that didn't actually occur.
     */
    fun applyProfile(context: Context, mode: BoostMode): ModuleApplyResult {
        val profile = profileFor(mode)
        val changes = mutableListOf<String>()

        // Thermal safety net: Performance mode's higher brightness is only safe
        // while the device is actually cool. If the battery is already warm/hot,
        // forcing 70% brightness on top of that is exactly what makes a hot phone
        // hotter — so we automatically step it down and say so, instead of
        // blindly applying the profile's number.
        val thermalLevel = ThermalGuardManager.levelFor(ThermalGuardManager.currentBatteryTempCelsius(context))
        val effectiveBrightness = if (mode == BoostMode.PERFORMANCE) {
            when (thermalLevel) {
                ThermalLevel.HOT -> 40
                ThermalLevel.WARM -> 55
                ThermalLevel.COOL -> profile.brightnessPercent
            }
        } else profile.brightnessPercent

        if (Settings.System.canWrite(context)) {
            val resolver = context.contentResolver
            effectiveBrightness?.let { pct ->
                val value = (pct / 100.0 * 255).toInt().coerceIn(1, 255)
                runCatching {
                    Settings.System.putInt(resolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                    Settings.System.putInt(resolver, Settings.System.SCREEN_BRIGHTNESS, value)
                }.onSuccess {
                    changes.add(
                        if (mode == BoostMode.PERFORMANCE && thermalLevel != ThermalLevel.COOL)
                            "Brightness $pct% (diturunkan otomatis, HP sedang ${if (thermalLevel == ThermalLevel.HOT) "panas" else "hangat"})"
                        else "Brightness $pct%"
                    )
                }
            }
            if (profile.restoreAutoBrightness) {
                runCatching {
                    Settings.System.putInt(resolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC)
                }.onSuccess { changes.add("Adaptive brightness restored") }
            }
            profile.screenTimeoutSeconds?.let { secs ->
                runCatching {
                    Settings.System.putInt(resolver, Settings.System.SCREEN_OFF_TIMEOUT, secs * 1000)
                }.onSuccess { changes.add("Screen timeout ${secs}s") }
            }
        } else {
            changes.add("Grant 'Modify system settings' to control brightness/timeout")
        }

        if (profile.trimBackground) {
            val killed = BoosterEngine.trimBackgroundProcesses(context)
            changes.add("Trimmed $killed background app(s)")
        } else {
            changes.add("Background trim skipped (saves battery)")
        }

        return ModuleApplyResult(profile, changes)
    }

    /**
     * The polling interval to actually use for the live-stats loop —
     * the mode's requested speed, clamped to what this specific device can
     * sustain without the monitor itself becoming a meaningful CPU/battery
     * cost. On a flagship this equals `profileFor(mode).pollingIntervalMs`
     * exactly; on a low-RAM device it's slower, honestly, instead of
     * pretending every device can handle a 500ms loop.
     */
    fun effectivePollingMs(context: Context, mode: BoostMode): Long {
        val requested = profileFor(mode).pollingIntervalMs
        val floor = DeviceCompat.classify(context).pollingFloorMs
        return maxOf(requested, floor)
    }
}

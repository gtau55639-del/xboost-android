package com.xboost.app.ui.screens

import android.app.Activity
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.xboost.app.core.*
import com.xboost.app.overlay.FloatingPanelService
import com.xboost.app.overlay.FpsOverlayService
import com.xboost.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ModulesScreen(onOpenAppLock: () -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    val activity = context as? Activity
    val scope = rememberCoroutineScope()
    val lifecycleOwner = LocalLifecycleOwner.current

    val enabledFns by PreferencesManager.enabledFunctions(context).collectAsState(initial = setOf("clear_cache", "game_dnd"))
    val autoGameMode by PreferencesManager.autoGameMode(context).collectAsState(initial = false)
    val fpsOverlayOn by PreferencesManager.fpsOverlayOn(context).collectAsState(initial = false)
    val floatingPanelOn by PreferencesManager.floatingPanelOn(context).collectAsState(initial = false)
    val thermalGuardOn by PreferencesManager.thermalGuardOn(context).collectAsState(initial = false)
    val displayRefreshOn by PreferencesManager.displayRefreshOn(context).collectAsState(initial = false)

    var overlayGranted by remember { mutableStateOf(PermissionManager.hasOverlayPermission(context)) }
    var batteryExempt by remember { mutableStateOf(PermissionManager.isIgnoringBatteryOptimizations(context)) }
    var refreshInfo by remember { mutableStateOf(DisplayRefreshManager.currentInfo(context)) }
    var tempC by remember { mutableStateOf(ThermalGuardManager.currentBatteryTempCelsius(context)) }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                overlayGranted = PermissionManager.hasOverlayPermission(context)
                batteryExempt = PermissionManager.isIgnoringBatteryOptimizations(context)
                refreshInfo = DisplayRefreshManager.currentInfo(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Live temperature readout while this screen is open — real value, refreshed every 2s.
    LaunchedEffect(Unit) {
        while (true) {
            tempC = ThermalGuardManager.currentBatteryTempCelsius(context)
            delay(2000)
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(Bg0).verticalScrollFix().padding(horizontal = 20.dp, vertical = 24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Text1, modifier = Modifier.clickable { onBack() })
            Spacer(Modifier.width(10.dp))
            Text("MODULES", color = Text0, fontWeight = FontWeight.Bold, fontSize = 19.sp)
        }
        Text(
            "Pick which modules run. Every one of these does something real on your device — nothing here is a placebo switch.",
            color = Text2, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp, bottom = 18.dp)
        )

        // 1. Background Trim
        ModuleCard(
            icon = Icons.Filled.CleaningServices, title = "Background Trim",
            desc = "Asks the OS to kill idle cached apps before you boost",
            on = enabledFns.contains("clear_cache"),
            onToggle = { on -> scope.launch { PreferencesManager.toggleFunction(context, "clear_cache", on) } }
        )
        // 2. Game DND
        ModuleCard(
            icon = Icons.Filled.DoNotDisturbOn, title = "Game DND",
            desc = "Silences notifications system-wide while boosted",
            on = enabledFns.contains("game_dnd"),
            onToggle = { on ->
                scope.launch { PreferencesManager.toggleFunction(context, "game_dnd", on) }
                BoosterEngine.setGameDnd(context, on)
            }
        )
        // 3. Screen Awake
        ModuleCard(
            icon = Icons.Filled.Visibility, title = "Screen Awake",
            desc = "Keeps the display on while XBoost is in the foreground",
            on = enabledFns.contains("keep_screen_on"),
            onToggle = { on ->
                scope.launch { PreferencesManager.toggleFunction(context, "keep_screen_on", on) }
                activity?.window?.let { BoosterEngine.setKeepScreenOn(it, on) }
            }
        )
        // 4. Auto Game Mode
        ModuleCard(
            icon = Icons.Filled.AutoAwesome, title = "Auto Game Mode",
            desc = "Applies each game's saved profile the moment it opens",
            on = autoGameMode,
            onToggle = { on -> scope.launch { PreferencesManager.setAutoGameMode(context, on) } }
        )
        // 5. FPS Overlay
        ModuleCard(
            icon = Icons.Filled.Insights, title = "FPS Boost Overlay",
            desc = if (!overlayGranted) "Grant 'Display over other apps' first" else "Live FPS counter floating over any game",
            on = fpsOverlayOn,
            enabled = overlayGranted,
            onToggle = { on ->
                scope.launch { PreferencesManager.setFpsOverlayOn(context, on) }
                val intent = Intent(context, FpsOverlayService::class.java)
                if (on) context.startForegroundService(intent) else context.stopService(intent)
            }
        )
        // 6. App Lock (navigate)
        ModuleNavigateCard(
            icon = Icons.Filled.Lock, title = "App Lock",
            desc = "PIN-protect selected apps",
            onClick = onOpenAppLock
        )
        // 6b. Floating Quick Panel
        ModuleCard(
            icon = Icons.Filled.TouchApp, title = "Floating Quick Panel",
            desc = if (!overlayGranted) "Grant 'Display over other apps' first" else "Draggable bubble with Trim/DND/Open shortcuts over any app",
            on = floatingPanelOn,
            enabled = overlayGranted,
            onToggle = { on ->
                scope.launch { PreferencesManager.setFloatingPanelOn(context, on) }
                val intent = Intent(context, FloatingPanelService::class.java)
                if (on) context.startForegroundService(intent) else context.stopService(intent)
            }
        )
        // 7. Display Refresh / 120Hz
        Column(
            modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp)).padding(14.dp)
        ) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Speed, contentDescription = null, tint = if (displayRefreshOn) XCyan else Text1, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("High Refresh Rate", color = Text0, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        Text(
                            "Device supports up to ${refreshInfo.maxRate.toInt()}Hz, running at ${refreshInfo.currentRate.toInt()}Hz now",
                            color = Text2, fontSize = 10.sp
                        )
                    }
                }
                Switch(
                    checked = displayRefreshOn,
                    enabled = refreshInfo.highRefreshAvailable,
                    onCheckedChange = { on ->
                        scope.launch { PreferencesManager.setDisplayRefreshOn(context, on) }
                        if (on) activity?.let { DisplayRefreshManager.requestHighRefreshForThisWindow(it) }
                    },
                    colors = SwitchDefaults.colors(checkedThumbColor = XCyan, checkedTrackColor = XCyanDim)
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "This only raises XBoost's own refresh rate — no non-root app can force other games into 120Hz. " +
                "For the real system-wide toggle:",
                color = Text2, fontSize = 9.5.sp, lineHeight = 13.sp
            )
            Spacer(Modifier.height(6.dp))
            Button(
                onClick = { DisplayRefreshManager.openSystemDisplaySettings(context) },
                colors = ButtonDefaults.buttonColors(containerColor = Bg1),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text("Open Display Settings", fontSize = 10.sp, color = Text0)
            }
        }
        Spacer(Modifier.height(10.dp))

        // 8. Thermal Guard
        Column(
            modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp)).padding(14.dp)
        ) {
            val level = ThermalGuardManager.levelFor(tempC)
            val levelColor = when (level) { ThermalLevel.HOT -> XRed; ThermalLevel.WARM -> XAmber; ThermalLevel.COOL -> XCyan }
            Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Thermostat, contentDescription = null, tint = levelColor, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Thermal Guard", color = Text0, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        Text(
                            tempC?.let { "%.1f°C — ${level.name.lowercase()}".format(it) } ?: "Reading unavailable",
                            color = levelColor, fontSize = 10.sp
                        )
                    }
                }
                Switch(
                    checked = thermalGuardOn,
                    onCheckedChange = { on -> scope.launch { PreferencesManager.setThermalGuardOn(context, on) } },
                    colors = SwitchDefaults.colors(checkedThumbColor = XAmber, checkedTrackColor = XCyanDim)
                )
            }
            if (thermalGuardOn) {
                Spacer(Modifier.height(6.dp))
                Text(
                    "Reads real battery temperature while XBoost is open. No background alarm — that would mean another persistent notification just for a temperature check.",
                    color = Text2, fontSize = 9.5.sp, lineHeight = 13.sp
                )
            }
        }
        Spacer(Modifier.height(10.dp))

        // 9. Battery Optimization Exemption
        Column(
            modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp)).padding(14.dp)
        ) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.BatteryChargingFull, contentDescription = null, tint = if (batteryExempt) XCyan else Text1, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Background Persistence", color = Text0, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        Text(
                            if (batteryExempt) "Exempted — App Lock & FPS Overlay survive longer" else "Not exempted — OEMs may kill background modules",
                            color = if (batteryExempt) XCyan else Text2, fontSize = 10.sp
                        )
                    }
                }
                if (!batteryExempt) {
                    Button(
                        onClick = { PermissionManager.requestIgnoreBatteryOptimizations(context) },
                        colors = ButtonDefaults.buttonColors(containerColor = XRed),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) { Text("Exempt", fontSize = 11.sp) }
                }
            }
        }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Modifier.verticalScrollFix(): Modifier {
    val scrollState = rememberScrollState()
    return this.verticalScroll(scrollState)
}

@Composable
private fun ModuleCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    desc: String,
    on: Boolean,
    enabled: Boolean = true,
    onToggle: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Panel, RoundedCornerShape(14.dp))
            .border(1.dp, Line, RoundedCornerShape(14.dp))
            .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Icon(icon, contentDescription = null, tint = if (on) XCyan else Text1, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                Text(title, color = Text0, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Text(desc, color = Text2, fontSize = 10.sp)
            }
        }
        Switch(
            checked = on,
            enabled = enabled,
            onCheckedChange = onToggle,
            colors = SwitchDefaults.colors(checkedThumbColor = XCyan, checkedTrackColor = XCyanDim)
        )
    }
    Spacer(Modifier.height(10.dp))
}

@Composable
private fun ModuleNavigateCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    desc: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Panel, RoundedCornerShape(14.dp))
            .border(1.dp, Line, RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Icon(icon, contentDescription = null, tint = XRed, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                Text(title, color = Text0, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Text(desc, color = Text2, fontSize = 10.sp)
            }
        }
        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = Text2)
    }
    Spacer(Modifier.height(10.dp))
}

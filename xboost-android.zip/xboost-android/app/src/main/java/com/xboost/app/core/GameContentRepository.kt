package com.xboost.app.core

/**
 * Content for the two new per-game modules (Modules screen → "Game AI Assistant & Guide"):
 *
 *  - AI Tips Assistant: the user types a question, XBoost matches it against a small
 *    curated keyword→answer table for that game and returns the closest tip. This is
 *    an OFFLINE, on-device lookup — not a cloud model, and it never reads, controls, or
 *    injects input into the game itself. Framed honestly, same as every other module
 *    in this app: it's a searchable tips book, not a bot that plays for you.
 *  - Guide: a structured, always-visible list of general strategy/settings tips per game.
 *
 * All content here is original, general gameplay/settings advice (sensitivity, loadouts,
 * rotations, team comps) — nothing that reads memory, automates input, or gives an unfair
 * advantage over other players. That kind of tool is out of scope for XBoost by design.
 */
data class AssistantEntry(val keywords: List<String>, val answer: String)
data class GuideSection(val heading: String, val points: List<String>)

object GameContentRepository {

    private val genericAssistant = listOf(
        AssistantEntry(
            listOf("lag", "fps", "stutter", "patah", "nge-lag", "lemot"),
            "Coba mode Performance di tab Boost dulu (trim background + polling lebih ringan), " +
            "lalu cek FPS Boost Overlay di Modules buat lihat angka FPS asli saat main."
        ),
        AssistantEntry(
            listOf("panas", "hot", "suhu", "thermal", "overheat"),
            "Aktifkan Thermal Guard di Modules buat pantau suhu baterai real-time. Kalau sudah di " +
            "zona WARM/HOT, XBoost otomatis menurunkan kecerahan saat mode Performance dipakai."
        ),
        AssistantEntry(
            listOf("baterai", "battery", "boros", "hemat"),
            "Pindah ke mode Battery Save di tab Boost — timeout layar dipercepat, brightness diturunkan, " +
            "dan trim background di-skip biar gak nambah beban CPU."
        ),
        AssistantEntry(
            listOf("dc", "putus", "connection", "koneksi", "ping"),
            "Cek tab Network buat ping real ke internet. Kalau ping tinggi terus, itu biasanya jaringan/router, " +
            "bukan sesuatu yang bisa XBoost benerin dari sisi HP."
        )
    )

    private val genericGuide = listOf(
        GuideSection(
            "Sebelum mulai main",
            listOf(
                "Set profile game di tab Games: DND otomatis + layar tetap nyala.",
                "Nyalain Auto Game Mode biar profile itu jalan sendiri begitu game dibuka.",
                "Kalau device kerasa panas, cek Thermal Guard dulu sebelum sesi panjang."
            )
        ),
        GuideSection(
            "Setelan umum yang sering kepake",
            listOf(
                "Sensitivitas kamera: mulai dari default, naikkan sedikit-sedikit sambil latihan di mode latihan/bot match.",
                "Grafis: kalau FPS drop, turunkan satu tingkat dulu sebelum ganti resolusi — biasanya paling kerasa efeknya.",
                "Kontrol/tombol: custom layout HUD sesuai ukuran tangan, jangan ikut-ikutan layout orang lain."
            )
        )
    )

    private val perGame: Map<String, Pair<List<AssistantEntry>, List<GuideSection>>> = mapOf(
        "com.tencent.ig" to (
            listOf(
                AssistantEntry(
                    listOf("drop", "landing", "mendarat"),
                    "Drop di pinggir map rame kalau mau farming loot aman, drop tengah map kalau mau latihan fight lebih sering."
                ),
                AssistantEntry(
                    listOf("loot", "senjata", "weapon"),
                    "Prioritas awal: body armor + weapon apa aja buat jaga-jaga, baru upgrade ke senjata & attachment pilihan setelah aman."
                ),
                AssistantEntry(
                    listOf("zona", "circle", "rotasi", "rotate"),
                    "Selalu cek arah zona berikutnya dari early game, jangan nunggu zona nutup baru rotasi — itu yang paling sering bikin kena damage zona."
                )
            ) to listOf(
                GuideSection("Awal permainan", listOf(
                    "Drop sesuai gaya main: aman di pinggir, agresif di tengah.",
                    "Ambil armor & healing dulu sebelum grinding attachment."
                )),
                GuideSection("Rotasi & zona", listOf(
                    "Rotasi lebih awal daripada telat — jalan kaki di akhir zona sangat berisiko.",
                    "Manfaatkan kendaraan buat rotasi jarak jauh, tapi matikan suara mesin di area rame."
                ))
            )
        ),
        "com.mobile.legends" to (
            listOf(
                AssistantEntry(
                    listOf("jungle", "hutan", "buff"),
                    "Ambil buff merah dulu di awal buat sustain, prioritaskan buff biru buat role mage/mana-hungry."
                ),
                AssistantEntry(
                    listOf("rotasi", "gank", "roam"),
                    "Rotasi ke lane yang push duluan atau lagi low HP — gank yang telat lebih sering rugi daripada untung."
                ),
                AssistantEntry(
                    listOf("build", "item", "emblem"),
                    "Sesuaikan build sama komposisi musuh tiap match, jangan pakai build fix dari awal ke awal."
                )
            ) to listOf(
                GuideSection("Role dasar", listOf(
                    "Jungle: fokus farm + objective (turtle/lord), bukan ngejar kill terus.",
                    "Roam: sediakan vision & save carry, bukan cuma jalan bareng carry."
                )),
                GuideSection("Draft pick", listOf(
                    "Ban hero yang paling sering nge-carry di rank kamu, bukan cuma yang kamu benci.",
                    "Pick counter di akhir draft kalau posisinya memungkinkan."
                ))
            )
        ),
        "com.miHoYo.GenshinImpact" to (
            listOf(
                AssistantEntry(
                    listOf("elemental", "reaction", "reaksi"),
                    "Reaksi Vaporize/Melt biasanya damage paling gede, tapi Electro-Charged/Superconduct berguna buat clear grup musuh."
                ),
                AssistantEntry(
                    listOf("stamina", "sprint", "climb"),
                    "Bawa food buff stamina buat eksplorasi panjang, dan cek Waypoint biar gak habis stamina di climbing sia-sia."
                ),
                AssistantEntry(
                    listOf("team", "party", "comp"),
                    "Susun party sekitar 1 main DPS + 1 sub-DPS + 1 support elemental + 1 healer/shielder buat kebanyakan konten."
                )
            ) to listOf(
                GuideSection("Team building", listOf(
                    "Cek elemen party — hindari overlap elemen yang gak saling sinergi.",
                    "Sisipkan minimal 1 support buat energy recharge kalau ultimate jadi andalan."
                )),
                GuideSection("Eksplorasi", listOf(
                    "Buka Waypoint duluan sebelum eksplorasi jauh biar gampang fast-travel balik.",
                    "Simpan resin buat domain/boss yang lagi kamu kejar, jangan asal pakai."
                ))
            )
        ),
        "com.activision.callofduty.shooter" to (
            listOf(
                AssistantEntry(
                    listOf("loadout", "class", "attachment"),
                    "Sesuaikan attachment sama range map: mobility buat map sempit, range/stability buat map terbuka."
                ),
                AssistantEntry(
                    listOf("sensitivity", "aim", "sensi"),
                    "Naikkan sensitivitas ADS pelan-pelan, jangan langsung tinggi — konsistensi lebih penting dari kecepatan mentah."
                )
            ) to listOf(
                GuideSection("Loadout", listOf(
                    "Punya minimal 2 loadout: 1 buat map sempit (SMG/mobility), 1 buat map terbuka (AR/sniper).",
                    "Cek perk yang cocok sama gaya main (aggressive vs objective-holder)."
                ))
            )
        ),
        "com.dts.freefireth" to (
            listOf(
                AssistantEntry(
                    listOf("drop", "landing", "mendarat"),
                    "Drop di pojok map buat farming aman, drop dekat pesawat kalau mau latihan early fight."
                ),
                AssistantEntry(
                    listOf("zona", "rotasi"),
                    "Karena map lebih kecil dari game battle royale lain, rotasi lebih cepat penting — jangan nunggu zona final buat gerak."
                )
            ) to listOf(
                GuideSection("Awal permainan", listOf(
                    "Prioritaskan gloo wall & healing item di early game buat survive rotasi.",
                    "Perhatikan karakter/skill combo yang dipakai — sesuaikan sama gaya main solo/squad."
                ))
            )
        )
    )

    fun guideFor(pkg: String): List<GuideSection> =
        (perGame[pkg]?.second ?: emptyList()) + genericGuide

    private fun assistantEntriesFor(pkg: String): List<AssistantEntry> =
        (perGame[pkg]?.first ?: emptyList()) + genericAssistant

    /**
     * Very small on-device keyword match — first entry whose keyword appears
     * in the query wins. No network call, no LLM API key required to work.
     */
    fun answer(pkg: String, query: String): String? {
        val q = query.lowercase().trim()
        if (q.isBlank()) return null
        val entries = assistantEntriesFor(pkg)
        return entries.firstOrNull { entry -> entry.keywords.any { q.contains(it) } }?.answer
    }

    fun suggestedQuestions(pkg: String): List<String> =
        assistantEntriesFor(pkg).take(4).map { it.keywords.first() }
}

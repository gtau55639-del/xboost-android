package com.xboost.app.ui.nav

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.sp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.xboost.app.ui.screens.*
import com.xboost.app.ui.theme.*

sealed class XDestination(val route: String, val label: String, val icon: ImageVector) {
    data object Boost : XDestination("boost", "Boost", Icons.Filled.Bolt)
    data object Games : XDestination("games", "Games", Icons.Filled.SportsEsports)
    data object Network : XDestination("network", "Network", Icons.Filled.NetworkCheck)
    data object Metrics : XDestination("metrics", "Metrics", Icons.Filled.Insights)
    data object Settings : XDestination("settings", "Settings", Icons.Filled.Settings)
}

private val destinations = listOf(
    XDestination.Boost, XDestination.Games, XDestination.Network, XDestination.Metrics, XDestination.Settings
)

/**
 * Landscape layout: a side NavigationRail instead of a bottom bar. This is
 * the standard Material3 pattern for wide/landscape screens — a bottom bar
 * would eat vertical space that's already scarce in landscape on a phone.
 */
@Composable
fun XBoostApp(pendingRoute: String? = null) {
    val navController = rememberNavController()

    // One-shot navigation when XBoost is opened via a deep-link-style extra
    // (currently: the Floating Quick Panel's "Guide" shortcut).
    LaunchedEffect(pendingRoute) {
        if (!pendingRoute.isNullOrBlank()) {
            navController.navigate(pendingRoute) {
                launchSingleTop = true
            }
        }
    }

    Row(modifier = Modifier.fillMaxSize().background(Bg0)) {
        NavigationRail(containerColor = Bg1, contentColor = Text1) {
            val backStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = backStackEntry?.destination

            destinations.forEach { dest ->
                val selected = currentRoute?.hierarchy?.any { it.route == dest.route } == true
                NavigationRailItem(
                    selected = selected,
                    onClick = {
                        navController.navigate(dest.route) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    icon = { Icon(dest.icon, contentDescription = dest.label) },
                    label = { Text(dest.label, fontSize = 9.sp) },
                    colors = NavigationRailItemDefaults.colors(
                        selectedIconColor = XRed,
                        selectedTextColor = XRed,
                        unselectedIconColor = Text2,
                        unselectedTextColor = Text2,
                        indicatorColor = XRedDim
                    )
                )
            }
        }

        NavHost(
            navController = navController,
            startDestination = XDestination.Boost.route,
            modifier = Modifier.weight(1f)
        ) {
            composable(XDestination.Boost.route) { BoostScreen() }
            composable(XDestination.Games.route) {
                GamesScreen(onOpenAssistant = { pkg -> navController.navigate("game_assistant/$pkg") })
            }
            composable(XDestination.Network.route) { NetworkScreen() }
            composable(XDestination.Metrics.route) { MetricsScreen() }
            composable(XDestination.Settings.route) {
                SettingsScreen(
                    onOpenModules = { navController.navigate("modules") },
                    onOpenSupport = { navController.navigate("support") }
                )
            }
            composable("app_lock") {
                AppLockScreen(onBack = { navController.popBackStack() })
            }
            composable("modules") {
                ModulesScreen(
                    onOpenAppLock = { navController.navigate("app_lock") },
                    onOpenSplitScreen = { navController.navigate("split_screen") },
                    onBack = { navController.popBackStack() }
                )
            }
            composable("split_screen") {
                SplitScreenScreen(onBack = { navController.popBackStack() })
            }
            composable("support") {
                SupportScreen(onBack = { navController.popBackStack() })
            }
            composable("game_assistant/{pkg}") { backStackEntry ->
                val pkg = backStackEntry.arguments?.getString("pkg") ?: ""
                GameAssistantScreen(pkg = pkg, onBack = { navController.popBackStack() })
            }
        }
    }
}

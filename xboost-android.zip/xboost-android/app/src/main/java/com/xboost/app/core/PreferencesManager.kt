package com.xboost.app.core

import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import android.content.Context
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "xboost_prefs")

enum class BoostMode { BALANCE, PERFORMANCE, BATTERY_SAVE }
enum class AccentColor { RED, CYAN, PURPLE, GREEN }

object PreferencesManager {
    private val KEY_MODE = stringPreferencesKey("boost_mode")
    private val KEY_AUTO_GAME_MODE = booleanPreferencesKey("auto_game_mode")
    private val KEY_KEEP_SCREEN_ON = booleanPreferencesKey("keep_screen_on")
    private val KEY_GAME_DND = booleanPreferencesKey("game_dnd_enabled")
    private val KEY_ENABLED_FUNCTIONS = stringSetPreferencesKey("enabled_functions")

    // Game Mode Profiles: which installed games have DND / Screen Awake turned on for them
    private val KEY_PROFILE_DND_PKGS = stringSetPreferencesKey("profile_dnd_pkgs")
    private val KEY_PROFILE_SCREEN_PKGS = stringSetPreferencesKey("profile_screen_pkgs")

    // Personalization
    private val KEY_ACCENT = stringPreferencesKey("accent_color")

    // FPS overlay
    private val KEY_FPS_OVERLAY_ON = booleanPreferencesKey("fps_overlay_on")

    // App Lock
    private val KEY_LOCK_PIN_HASH = stringPreferencesKey("lock_pin_hash")
    private val KEY_LOCKED_PKGS = stringSetPreferencesKey("locked_pkgs")
    private val KEY_LOCK_SERVICE_ON = booleanPreferencesKey("lock_service_on")

    // Modules screen
    private val KEY_THERMAL_GUARD_ON = booleanPreferencesKey("thermal_guard_on")
    private val KEY_DISPLAY_REFRESH_ON = booleanPreferencesKey("display_refresh_on")
    private val KEY_FLOATING_PANEL_ON = booleanPreferencesKey("floating_panel_on")

    // Game AI Assistant & Guide module — offline per-game tips, no permission needed
    private val KEY_GAME_MODULES_ON = booleanPreferencesKey("game_modules_on")

    // Split Screen / dual-app launcher
    private val KEY_SPLIT_SCREEN_ON = booleanPreferencesKey("split_screen_on")
    private val KEY_SPLIT_APP_A = stringPreferencesKey("split_app_a")
    private val KEY_SPLIT_APP_B = stringPreferencesKey("split_app_b")

    // Floating Panel favorite apps (quick-launch icons shown in the expanded bubble)
    private val KEY_FLOATING_FAVORITE_PKGS = stringSetPreferencesKey("floating_favorite_pkgs")

    fun mode(context: Context): Flow<BoostMode> =
        context.dataStore.data.map { prefs ->
            when (prefs[KEY_MODE]) {
                "PERFORMANCE" -> BoostMode.PERFORMANCE
                "BATTERY_SAVE" -> BoostMode.BATTERY_SAVE
                else -> BoostMode.BALANCE
            }
        }

    suspend fun setMode(context: Context, mode: BoostMode) {
        context.dataStore.edit { it[KEY_MODE] = mode.name }
    }

    fun autoGameMode(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[KEY_AUTO_GAME_MODE] ?: false }

    suspend fun setAutoGameMode(context: Context, enabled: Boolean) {
        context.dataStore.edit { it[KEY_AUTO_GAME_MODE] = enabled }
    }

    fun keepScreenOn(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[KEY_KEEP_SCREEN_ON] ?: false }

    suspend fun setKeepScreenOn(context: Context, enabled: Boolean) {
        context.dataStore.edit { it[KEY_KEEP_SCREEN_ON] = enabled }
    }

    fun gameDndEnabled(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[KEY_GAME_DND] ?: false }

    suspend fun setGameDndEnabled(context: Context, enabled: Boolean) {
        context.dataStore.edit { it[KEY_GAME_DND] = enabled }
    }

    fun enabledFunctions(context: Context): Flow<Set<String>> =
        context.dataStore.data.map { it[KEY_ENABLED_FUNCTIONS] ?: emptySet() }

    suspend fun toggleFunction(context: Context, id: String, enabled: Boolean) {
        context.dataStore.edit { prefs ->
            val current = prefs[KEY_ENABLED_FUNCTIONS] ?: emptySet()
            prefs[KEY_ENABLED_FUNCTIONS] = if (enabled) current + id else current - id
        }
    }

    // ---------- Game Mode Profiles ----------

    fun profileDndPackages(context: Context): Flow<Set<String>> =
        context.dataStore.data.map { it[KEY_PROFILE_DND_PKGS] ?: emptySet() }

    fun profileScreenPackages(context: Context): Flow<Set<String>> =
        context.dataStore.data.map { it[KEY_PROFILE_SCREEN_PKGS] ?: emptySet() }

    suspend fun setProfileDnd(context: Context, pkg: String, enabled: Boolean) {
        context.dataStore.edit { prefs ->
            val current = prefs[KEY_PROFILE_DND_PKGS] ?: emptySet()
            prefs[KEY_PROFILE_DND_PKGS] = if (enabled) current + pkg else current - pkg
        }
    }

    suspend fun setProfileScreenAwake(context: Context, pkg: String, enabled: Boolean) {
        context.dataStore.edit { prefs ->
            val current = prefs[KEY_PROFILE_SCREEN_PKGS] ?: emptySet()
            prefs[KEY_PROFILE_SCREEN_PKGS] = if (enabled) current + pkg else current - pkg
        }
    }

    // ---------- Personalization ----------

    fun accentColor(context: Context): Flow<AccentColor> =
        context.dataStore.data.map { prefs ->
            runCatching { AccentColor.valueOf(prefs[KEY_ACCENT] ?: "RED") }.getOrDefault(AccentColor.RED)
        }

    suspend fun setAccentColor(context: Context, color: AccentColor) {
        context.dataStore.edit { it[KEY_ACCENT] = color.name }
    }

    // ---------- FPS overlay ----------

    fun fpsOverlayOn(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[KEY_FPS_OVERLAY_ON] ?: false }

    suspend fun setFpsOverlayOn(context: Context, on: Boolean) {
        context.dataStore.edit { it[KEY_FPS_OVERLAY_ON] = on }
    }

    // ---------- App Lock ----------

    fun lockPinHash(context: Context): Flow<String?> =
        context.dataStore.data.map { it[KEY_LOCK_PIN_HASH] }

    suspend fun setLockPinHash(context: Context, hash: String) {
        context.dataStore.edit { it[KEY_LOCK_PIN_HASH] = hash }
    }

    fun lockedPackages(context: Context): Flow<Set<String>> =
        context.dataStore.data.map { it[KEY_LOCKED_PKGS] ?: emptySet() }

    suspend fun setPackageLocked(context: Context, pkg: String, locked: Boolean) {
        context.dataStore.edit { prefs ->
            val current = prefs[KEY_LOCKED_PKGS] ?: emptySet()
            prefs[KEY_LOCKED_PKGS] = if (locked) current + pkg else current - pkg
        }
    }

    fun lockServiceOn(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[KEY_LOCK_SERVICE_ON] ?: false }

    suspend fun setLockServiceOn(context: Context, on: Boolean) {
        context.dataStore.edit { it[KEY_LOCK_SERVICE_ON] = on }
    }

    // ---------- Modules screen ----------

    fun thermalGuardOn(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[KEY_THERMAL_GUARD_ON] ?: false }

    suspend fun setThermalGuardOn(context: Context, on: Boolean) {
        context.dataStore.edit { it[KEY_THERMAL_GUARD_ON] = on }
    }

    fun displayRefreshOn(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[KEY_DISPLAY_REFRESH_ON] ?: false }

    suspend fun setDisplayRefreshOn(context: Context, on: Boolean) {
        context.dataStore.edit { it[KEY_DISPLAY_REFRESH_ON] = on }
    }

    fun floatingPanelOn(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[KEY_FLOATING_PANEL_ON] ?: false }

    suspend fun setFloatingPanelOn(context: Context, on: Boolean) {
        context.dataStore.edit { it[KEY_FLOATING_PANEL_ON] = on }
    }

    // ---------- Game AI Assistant & Guide ----------

    /** Default ON — it's an offline content lookup, needs no permission, nothing to protect against. */
    fun gameModulesOn(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[KEY_GAME_MODULES_ON] ?: true }

    suspend fun setGameModulesOn(context: Context, on: Boolean) {
        context.dataStore.edit { it[KEY_GAME_MODULES_ON] = on }
    }

    // ---------- Split Screen / dual-app launcher ----------

    fun splitScreenOn(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[KEY_SPLIT_SCREEN_ON] ?: false }

    suspend fun setSplitScreenOn(context: Context, on: Boolean) {
        context.dataStore.edit { it[KEY_SPLIT_SCREEN_ON] = on }
    }

    /** Pair of packages saved for the one-tap split-screen launch (App A, App B). */
    fun splitApps(context: Context): Flow<Pair<String?, String?>> =
        context.dataStore.data.map { it[KEY_SPLIT_APP_A] to it[KEY_SPLIT_APP_B] }

    suspend fun setSplitAppA(context: Context, pkg: String?) {
        context.dataStore.edit { prefs -> if (pkg == null) prefs.remove(KEY_SPLIT_APP_A) else prefs[KEY_SPLIT_APP_A] = pkg }
    }

    suspend fun setSplitAppB(context: Context, pkg: String?) {
        context.dataStore.edit { prefs -> if (pkg == null) prefs.remove(KEY_SPLIT_APP_B) else prefs[KEY_SPLIT_APP_B] = pkg }
    }

    // ---------- Floating Panel favorites (floating/hovering app shortcuts) ----------

    fun floatingFavorites(context: Context): Flow<Set<String>> =
        context.dataStore.data.map { it[KEY_FLOATING_FAVORITE_PKGS] ?: emptySet() }

    suspend fun setFloatingFavorite(context: Context, pkg: String, enabled: Boolean) {
        context.dataStore.edit { prefs ->
            val current = prefs[KEY_FLOATING_FAVORITE_PKGS] ?: emptySet()
            // cap at 4 favorites so the expanded bubble stays compact
            prefs[KEY_FLOATING_FAVORITE_PKGS] = if (enabled) (current + pkg).take(4).toSet() else current - pkg
        }
    }
}

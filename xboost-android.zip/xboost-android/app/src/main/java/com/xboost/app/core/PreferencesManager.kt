package com.xboost.app.core

import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import android.content.Context
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "xboost_prefs")

enum class BoostMode { BALANCE, PERFORMANCE, BATTERY_SAVE }
enum class AccentColor { RED, CYAN, PURPLE, GREEN }

object PreferencesManager {
    private val KEY_MODE = stringPreferencesKey("boost_mode")
    private val KEY_AUTO_GAME_MODE = booleanPreferencesKey("auto_game_mode")
    private val KEY_KEEP_SCREEN_ON = booleanPreferencesKey("keep_screen_on")
    private val KEY_GAME_DND = booleanPreferencesKey("game_dnd_enabled")
    private val KEY_ENABLED_FUNCTIONS = stringSetPreferencesKey("enabled_functions")

    // Game Mode Profiles: which installed games have DND / Screen Awake turned on for them
    private val KEY_PROFILE_DND_PKGS = stringSetPreferencesKey("profile_dnd_pkgs")
    private val KEY_PROFILE_SCREEN_PKGS = stringSetPreferencesKey("profile_screen_pkgs")

    // Personalization
    private val KEY_ACCENT = stringPreferencesKey("accent_color")

    // FPS overlay
    private val KEY_FPS_OVERLAY_ON = booleanPreferencesKey("fps_overlay_on")

    // App Lock
    private val KEY_LOCK_PIN_HASH = stringPreferencesKey("lock_pin_hash")
    private val KEY_LOCKED_PKGS = stringSetPreferencesKey("locked_pkgs")
    private val KEY_LOCK_SERVICE_ON = booleanPreferencesKey("lock_service_on")

    // Modules screen
    private val KEY_THERMAL_GUARD_ON = booleanPreferencesKey("thermal_guard_on")
    private val KEY_DISPLAY_REFRESH_ON = booleanPreferencesKey("display_refresh_on")
    private val KEY_FLOATING_PANEL_ON = booleanPreferencesKey("floating_panel_on")

    fun mode(context: Context): Flow<BoostMode> =
        context.dataStore.data.map { prefs ->
            when (prefs[KEY_MODE]) {
                "PERFORMANCE" -> BoostMode.PERFORMANCE
                "BATTERY_SAVE" -> BoostMode.BATTERY_SAVE
                else -> BoostMode.BALANCE
            }
        }

    suspend fun setMode(context: Context, mode: BoostMode) {
        context.dataStore.edit { it[KEY_MODE] = mode.name }
    }

    fun autoGameMode(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[KEY_AUTO_GAME_MODE] ?: false }

    suspend fun setAutoGameMode(context: Context, enabled: Boolean) {
        context.dataStore.edit { it[KEY_AUTO_GAME_MODE] = enabled }
    }

    fun keepScreenOn(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[KEY_KEEP_SCREEN_ON] ?: false }

    suspend fun setKeepScreenOn(context: Context, enabled: Boolean) {
        context.dataStore.edit { it[KEY_KEEP_SCREEN_ON] = enabled }
    }

    fun gameDndEnabled(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[KEY_GAME_DND] ?: false }

    suspend fun setGameDndEnabled(context: Context, enabled: Boolean) {
        context.dataStore.edit { it[KEY_GAME_DND] = enabled }
    }

    fun enabledFunctions(context: Context): Flow<Set<String>> =
        context.dataStore.data.map { it[KEY_ENABLED_FUNCTIONS] ?: emptySet() }

    suspend fun toggleFunction(context: Context, id: String, enabled: Boolean) {
        context.dataStore.edit { prefs ->
            val current = prefs[KEY_ENABLED_FUNCTIONS] ?: emptySet()
            prefs[KEY_ENABLED_FUNCTIONS] = if (enabled) current + id else current - id
        }
    }

    // ---------- Game Mode Profiles ----------

    fun profileDndPackages(context: Context): Flow<Set<String>> =
        context.dataStore.data.map { it[KEY_PROFILE_DND_PKGS] ?: emptySet() }

    fun profileScreenPackages(context: Context): Flow<Set<String>> =
        context.dataStore.data.map { it[KEY_PROFILE_SCREEN_PKGS] ?: emptySet() }

    suspend fun setProfileDnd(context: Context, pkg: String, enabled: Boolean) {
        context.dataStore.edit { prefs ->
            val current = prefs[KEY_PROFILE_DND_PKGS] ?: emptySet()
            prefs[KEY_PROFILE_DND_PKGS] = if (enabled) current + pkg else current - pkg
        }
    }

    suspend fun setProfileScreenAwake(context: Context, pkg: String, enabled: Boolean) {
        context.dataStore.edit { prefs ->
            val current = prefs[KEY_PROFILE_SCREEN_PKGS] ?: emptySet()
            prefs[KEY_PROFILE_SCREEN_PKGS] = if (enabled) current + pkg else current - pkg
        }
    }

    // ---------- Personalization ----------

    fun accentColor(context: Context): Flow<AccentColor> =
        context.dataStore.data.map { prefs ->
            runCatching { AccentColor.valueOf(prefs[KEY_ACCENT] ?: "RED") }.getOrDefault(AccentColor.RED)
        }

    suspend fun setAccentColor(context: Context, color: AccentColor) {
        context.dataStore.edit { it[KEY_ACCENT] = color.name }
    }

    // ---------- FPS overlay ----------

    fun fpsOverlayOn(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[KEY_FPS_OVERLAY_ON] ?: false }

    suspend fun setFpsOverlayOn(context: Context, on: Boolean) {
        context.dataStore.edit { it[KEY_FPS_OVERLAY_ON] = on }
    }

    // ---------- App Lock ----------

    fun lockPinHash(context: Context): Flow<String?> =
        context.dataStore.data.map { it[KEY_LOCK_PIN_HASH] }

    suspend fun setLockPinHash(context: Context, hash: String) {
        context.dataStore.edit { it[KEY_LOCK_PIN_HASH] = hash }
    }

    fun lockedPackages(context: Context): Flow<Set<String>> =
        context.dataStore.data.map { it[KEY_LOCKED_PKGS] ?: emptySet() }

    suspend fun setPackageLocked(context: Context, pkg: String, locked: Boolean) {
        context.dataStore.edit { prefs ->
            val current = prefs[KEY_LOCKED_PKGS] ?: emptySet()
            prefs[KEY_LOCKED_PKGS] = if (locked) current + pkg else current - pkg
        }
    }

    fun lockServiceOn(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[KEY_LOCK_SERVICE_ON] ?: false }

    suspend fun setLockServiceOn(context: Context, on: Boolean) {
        context.dataStore.edit { it[KEY_LOCK_SERVICE_ON] = on }
    }

    // ---------- Modules screen ----------

    fun thermalGuardOn(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[KEY_THERMAL_GUARD_ON] ?: false }

    suspend fun setThermalGuardOn(context: Context, on: Boolean) {
        context.dataStore.edit { it[KEY_THERMAL_GUARD_ON] = on }
    }

    fun displayRefreshOn(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[KEY_DISPLAY_REFRESH_ON] ?: false }

    suspend fun setDisplayRefreshOn(context: Context, on: Boolean) {
        context.dataStore.edit { it[KEY_DISPLAY_REFRESH_ON] = on }
    }

    fun floatingPanelOn(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[KEY_FLOATING_PANEL_ON] ?: false }

    suspend fun setFloatingPanelOn(context: Context, on: Boolean) {
        context.dataStore.edit { it[KEY_FLOATING_PANEL_ON] = on }
    }
}

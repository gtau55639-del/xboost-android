package com.xboost.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DoNotDisturbOn
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xboost.app.core.BoosterEngine
import com.xboost.app.core.PreferencesManager
import com.xboost.app.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun GamesScreen(onOpenAssistant: (String) -> Unit = {}) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val installed = remember(context) { BoosterEngine.installedKnownGames(context) }

    val dndProfiles by PreferencesManager.profileDndPackages(context).collectAsState(initial = emptySet())
    val screenProfiles by PreferencesManager.profileScreenPackages(context).collectAsState(initial = emptySet())
    val gameModulesOn by PreferencesManager.gameModulesOn(context).collectAsState(initial = true)

    Column(
        modifier = Modifier.fillMaxSize().background(Bg0).padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Text("GAME LIBRARY", color = Text0, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Text(
            "Detected from apps actually installed on this device. Set a profile per game — " +
            "Auto Game Mode (Boost tab) applies it automatically when that game opens.",
            color = Text2, fontSize = 10.sp,
            modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
        )

        if (installed.isEmpty()) {
            EmptyState()
        } else {
            // 2-column grid uses landscape width instead of one long vertical list.
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(installed) { (pkg, name) ->
                    GameRow(
                        name = name,
                        dndOn = dndProfiles.contains(pkg),
                        screenOn = screenProfiles.contains(pkg),
                        onDndToggle = { on -> scope.launch { PreferencesManager.setProfileDnd(context, pkg, on) } },
                        onScreenToggle = { on -> scope.launch { PreferencesManager.setProfileScreenAwake(context, pkg, on) } },
                        showAssistant = gameModulesOn,
                        onOpenAssistant = { onOpenAssistant(pkg) }
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyState() {
    Column(
        modifier = Modifier.fillMaxWidth().padding(top = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Filled.SportsEsports, contentDescription = null, tint = Text2, modifier = Modifier.size(40.dp))
        Spacer(Modifier.height(10.dp))
        Text("No known games detected", color = Text1, fontSize = 13.sp)
        Text(
            "XBoost only lists games it can verify are installed — no placeholder entries.",
            color = Text2, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
private fun GameRow(
    name: String,
    dndOn: Boolean,
    screenOn: Boolean,
    onDndToggle: (Boolean) -> Unit,
    onScreenToggle: (Boolean) -> Unit,
    showAssistant: Boolean,
    onOpenAssistant: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Panel, RoundedCornerShape(14.dp))
            .border(1.dp, Line, RoundedCornerShape(14.dp))
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.SportsEsports, contentDescription = null, tint = XCyan, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(10.dp))
            Text(name, color = Text0, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        }
        Spacer(Modifier.height(10.dp))
        ProfileToggleRow(Icons.Filled.DoNotDisturbOn, "Auto DND for this game", dndOn, onDndToggle)
        Spacer(Modifier.height(6.dp))
        ProfileToggleRow(Icons.Filled.Visibility, "Keep screen awake", screenOn, onScreenToggle)
        if (showAssistant) {
            Spacer(Modifier.height(10.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(XCyanDim, RoundedCornerShape(10.dp))
                    .clickable { onOpenAssistant() }
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.SmartToy, contentDescription = null, tint = XCyan, modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(8.dp))
                Text("AI Tips & Guide", color = XCyan, fontSize = 11.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun ProfileToggleRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, on: Boolean, onToggle: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = if (on) XCyan else Text2, modifier = Modifier.size(15.dp))
            Spacer(Modifier.width(8.dp))
            Text(label, color = Text1, fontSize = 12.sp)
        }
        Switch(
            checked = on,
            onCheckedChange = onToggle,
            colors = SwitchDefaults.colors(checkedThumbColor = XCyan, checkedTrackColor = XCyanDim),
            modifier = Modifier.height(20.dp)
        )
    }
}

package com.xboost.app.core

/**
 * Fill these in with your own real accounts before release. Left as
 * placeholders on purpose — inventing fake donation/social links would be
 * dishonest and could send users somewhere unintended.
 */
object DeveloperInfo {
    const val DEVELOPER_NAME = "XBoost Team"          // TODO: replace with your name/studio
    const val SUPPORT_EMAIL = "support@example.com"    // TODO: replace with your real support email
    const val DONATION_URL = "https://saweria.co/yourname"   // TODO: replace with your real Saweria/Trakteer/Ko-fi link
    const val TELEGRAM_URL = ""                        // TODO: e.g. https://t.me/yourchannel — leave blank to hide
    const val INSTAGRAM_URL = ""                        // TODO: e.g. https://instagram.com/yourhandle — leave blank to hide
}

package com.xboost.app.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xboost.app.core.PermissionManager
import com.xboost.app.core.PreferencesManager
import com.xboost.app.lock.LockGuardService
import com.xboost.app.lock.PinHasher
import com.xboost.app.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun AppLockScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val pinHash by PreferencesManager.lockPinHash(context).collectAsState(initial = null)
    val lockedPkgs by PreferencesManager.lockedPackages(context).collectAsState(initial = emptySet())
    val serviceOn by PreferencesManager.lockServiceOn(context).collectAsState(initial = false)
    var overlayGranted by remember { mutableStateOf(PermissionManager.hasOverlayPermission(context)) }

    var newPin by remember { mutableStateOf("") }

    val installedApps = remember {
        context.packageManager.getInstalledApplications(0)
            .filter { it.packageName != context.packageName && (it.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) == 0 }
            .sortedBy { context.packageManager.getApplicationLabel(it).toString() }
            .take(60) // keep the list snappy; a search field is a natural next step
    }

    Column(modifier = Modifier.fillMaxSize().background(Bg0).padding(horizontal = 20.dp, vertical = 24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Text1, modifier = Modifier.clickable { onBack() })
            Spacer(Modifier.width(10.dp))
            Text("APP LOCK", color = Text0, fontWeight = FontWeight.Bold, fontSize = 19.sp)
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "Locks selected apps behind a PIN while XBoost's guard service is running.",
            color = Text2, fontSize = 11.sp, modifier = Modifier.padding(bottom = 16.dp)
        )

        if (!overlayGranted) {
            Column(
                modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).border(1.dp, XAmber.copy(alpha = .4f), RoundedCornerShape(14.dp)).padding(14.dp)
            ) {
                Text("Display over other apps needed", color = Text0, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                Text("Required so the PIN screen can appear over a locked app.", color = Text2, fontSize = 10.sp, modifier = Modifier.padding(top = 2.dp, bottom = 8.dp))
                Button(onClick = { PermissionManager.openOverlaySettings(context) }, colors = ButtonDefaults.buttonColors(containerColor = XRed)) {
                    Text("Grant", fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
        }

        // --- PIN setup ---
        Text(if (pinHash == null) "SET A PIN" else "PIN IS SET", color = Text1, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = newPin,
                onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) newPin = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("4-digit PIN") },
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true
            )
            Spacer(Modifier.width(8.dp))
            Button(
                enabled = newPin.length == 4,
                onClick = {
                    scope.launch { PreferencesManager.setLockPinHash(context, PinHasher.hash(newPin)) }
                    newPin = ""
                },
                colors = ButtonDefaults.buttonColors(containerColor = XCyan)
            ) { Text("Save", fontSize = 12.sp) }
        }

        Spacer(Modifier.height(20.dp))

        // --- Guard service toggle ---
        Row(
            modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp)).padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Lock guard service", color = Text0, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Text(
                    if (serviceOn) "Running — locked apps are protected" else "Stopped — locked apps open freely",
                    color = if (serviceOn) XCyan else Text2, fontSize = 10.sp
                )
            }
            Switch(
                checked = serviceOn,
                onCheckedChange = { on ->
                    scope.launch { PreferencesManager.setLockServiceOn(context, on) }
                    if (on && pinHash != null && overlayGranted) {
                        val intent = Intent(context, LockGuardService::class.java).apply {
                            putStringArrayListExtra(LockGuardService.EXTRA_LOCKED_PKGS, ArrayList(lockedPkgs))
                        }
                        context.startForegroundService(intent)
                    } else {
                        context.stopService(Intent(context, LockGuardService::class.java))
                    }
                },
                colors = SwitchDefaults.colors(checkedThumbColor = XCyan, checkedTrackColor = XCyanDim)
            )
        }

        Spacer(Modifier.height(20.dp))
        Text("CHOOSE APPS TO LOCK", color = Text1, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Spacer(Modifier.height(8.dp))

        LazyColumn(modifier = Modifier.weight(1f)) {
            items(installedApps) { app ->
                val pkg = app.packageName
                val label = context.packageManager.getApplicationLabel(app).toString()
                val locked = lockedPkgs.contains(pkg)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            scope.launch { PreferencesManager.setPackageLocked(context, pkg, !locked) }
                        }
                        .padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.Lock, contentDescription = null, tint = if (locked) XRed else Text2, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(10.dp))
                        Text(label, color = Text0, fontSize = 13.sp)
                    }
                    Switch(
                        checked = locked,
                        onCheckedChange = { on -> scope.launch { PreferencesManager.setPackageLocked(context, pkg, on) } },
                        colors = SwitchDefaults.colors(checkedThumbColor = XRed, checkedTrackColor = XRedDim)
                    )
                }
            }
        }
    }
}

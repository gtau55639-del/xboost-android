package com.xboost.app.overlay

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.xboost.app.MainActivity
import com.xboost.app.R
import com.xboost.app.core.BoosterEngine
import com.xboost.app.core.DeviceCompat
import com.xboost.app.core.PreferencesManager
import com.xboost.app.core.SplitScreenManager
import com.xboost.app.core.ThermalGuardManager
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlin.math.abs

/**
 * A small draggable bubble that expands into a real "Game Mode" style quick
 * panel — the same pattern as Samsung Game Booster / RedMagic's in-game
 * overlay: live temperature, module toggles, and a shortcut into the
 * per-game AI Assistant & Guide. Every action here calls the same real
 * BoosterEngine / PreferencesManager functions used elsewhere in the app —
 * a different entry point to real actions, not new placebo buttons.
 */
class FloatingPanelService : Service() {

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var panelView: View? = null
    private var tempLabel: TextView? = null
    private var fpsButton: TextView? = null
    private var expanded = false
    private var fpsRunning = false

    private val mainHandler = Handler(Looper.getMainLooper())
    // Device-aware tick interval: never faster than DeviceCompat's polling
    // floor for this RAM tier, so a 1-2GB phone isn't paying for a 3s wakeup
    // loop it can't spare while a game is running. Same real numbers already
    // used for the live-stat polling elsewhere (DeviceCompat.classify).
    private var tempTickIntervalMs = 3000L
    private val tempTicker = object : Runnable {
        override fun run() {
            tempLabel?.text = tempDisplayText()
            mainHandler.postDelayed(this, tempTickIntervalMs)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        tempTickIntervalMs = maxOf(3000L, DeviceCompat.classify(applicationContext).pollingFloorMs * 2)
        startForeground(NOTIF_ID, buildNotification())
        fpsRunning = runCatching {
            runBlocking { PreferencesManager.fpsOverlayOn(applicationContext).first() }
        }.getOrDefault(false)
        addBubble()
    }

    override fun onDestroy() {
        mainHandler.removeCallbacks(tempTicker)
        bubbleView?.let { runCatching { windowManager.removeView(it) } }
        panelView?.let { runCatching { windowManager.removeView(it) } }
        super.onDestroy()
    }

    private fun tempDisplayText(): String {
        val c = ThermalGuardManager.currentBatteryTempCelsius(applicationContext) ?: return "--°C"
        val level = ThermalGuardManager.levelFor(c)
        val tag = level.name.take(1) // C / W / H
        return "%.1f°C·%s".format(c, tag)
    }

    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun addBubble() {
        val bubble = TextView(this).apply {
            text = "X"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#FF2B45"))
            textSize = 14f
            setPadding(28, 20, 28, 20)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 300
        }

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        bubble.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = params.x; startY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (abs(dx) > 8 || abs(dy) > 8) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    runCatching { windowManager.updateViewLayout(v, params) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) toggleExpanded()
                    true
                }
                else -> false
            }
        }

        windowManager.addView(bubble, params)
        bubbleView = bubble
    }

    private fun toggleExpanded() {
        expanded = !expanded
        if (expanded) addPanel() else removePanel()
    }

    private fun addPanel() {
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#E60D0E15"))
            setPadding(16, 12, 16, 12)
        }

        // Live temperature readout — real value from ThermalGuardManager, ticking every 3s
        // while the panel is expanded, stopped the moment it's collapsed to save battery.
        val temp = TextView(this).apply {
            text = tempDisplayText()
            setTextColor(Color.parseColor("#FFB020"))
            textSize = 10.5f
            setPadding(20, 0, 20, 8)
        }
        tempLabel = temp
        column.addView(temp)
        mainHandler.post(tempTicker)

        // Floating favorite apps — up to 4 quick-launch shortcuts chosen in
        // Modules → Split Screen & Floating Apps. This is the "floating,
        // hovering app" launcher: one tap opens the app on top of whatever
        // game/app is currently running, no need to leave it first.
        val favorites = runCatching {
            runBlocking { PreferencesManager.floatingFavorites(applicationContext).first() }
        }.getOrDefault(emptySet())
        // Cap at 2 icons on a LOW-tier (~1-3GB) device instead of 4: fewer
        // overlay child views to inflate/measure over an already-running
        // game. MID/HIGH devices (up to 12GB+) get the full 4.
        val tier = DeviceCompat.classify(applicationContext).tier
        val favoriteLimit = if (tier == com.xboost.app.core.DeviceTier.LOW) 2 else 4
        if (favorites.isNotEmpty()) {
            val favRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            favorites.take(favoriteLimit).forEach { pkg ->
                favRow.addView(actionButton(SplitScreenManager.label(applicationContext, pkg).take(8)) {
                    SplitScreenManager.launchPrimary(applicationContext, pkg)
                })
            }
            column.addView(favRow)
        }

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        row.addView(actionButton("Trim") {
            BoosterEngine.trimBackgroundProcesses(applicationContext)
        })
        row.addView(actionButton("DND") {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val turningOn = nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_PRIORITY
            BoosterEngine.setGameDnd(applicationContext, turningOn)
        })

        val fps = actionButton(fpsLabel()) { toggleFpsOverlay() }
        fpsButton = fps
        row.addView(fps)

        row.addView(actionButton("Guide") { openGuideForForegroundGame() })
        row.addView(actionButton("Split") { launchSplitPair() })
        row.addView(actionButton("Open") {
            val openIntent = Intent(applicationContext, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(openIntent)
        })
        row.addView(actionButton("Close") {
            stopSelf()
        })

        column.addView(row)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 360
        }

        windowManager.addView(column, params)
        panelView = column
    }

    private fun removePanel() {
        mainHandler.removeCallbacks(tempTicker)
        tempLabel = null
        fpsButton = null
        panelView?.let { runCatching { windowManager.removeView(it) } }
        panelView = null
    }

    private fun fpsLabel() = if (fpsRunning) "FPS✓" else "FPS"

    private fun toggleFpsOverlay() {
        fpsRunning = !fpsRunning
        val intent = Intent(applicationContext, FpsOverlayService::class.java)
        if (fpsRunning) startForegroundService(intent) else stopService(intent)
        runCatching { runBlocking { PreferencesManager.setFpsOverlayOn(applicationContext, fpsRunning) } }
        fpsButton?.text = fpsLabel()
    }

    /**
     * Opens XBoost straight into the AI Assistant & Guide tab for whichever
     * known game is currently in the foreground (needs Usage Access, same
     * permission Auto Game Mode already relies on). Falls back to the Game
     * Library if no known game is detected right now, instead of guessing.
     */
    private fun openGuideForForegroundGame() {
        val fg = runCatching { BoosterEngine.currentForegroundApp(applicationContext) }.getOrNull()
        val route = if (fg != null && BoosterEngine.KNOWN_GAMES.containsKey(fg)) "game_assistant/$fg" else "games"
        val openIntent = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
            putExtra(MainActivity.EXTRA_NAV_ROUTE, route)
        }
        startActivity(openIntent)
    }

    /**
     * Uses the App A / App B pair saved in Split Screen & Floating Apps.
     * Real behavior, same as the Split Screen screen's "Launch Split"
     * button — see SplitScreenManager for exactly what the adjacent-launch
     * flag can and can't do on a non-root device.
     */
    private fun launchSplitPair() {
        val (a, b) = runCatching {
            runBlocking { PreferencesManager.splitApps(applicationContext).first() }
        }.getOrDefault(null to null)
        if (a != null && b != null) {
            SplitScreenManager.launchPair(applicationContext, a, b)
        } else {
            val openIntent = Intent(applicationContext, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                putExtra(MainActivity.EXTRA_NAV_ROUTE, "split_screen")
            }
            startActivity(openIntent)
        }
    }

    private fun actionButton(label: String, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(Color.parseColor("#26F0D0"))
            textSize = 11f
            setPadding(20, 10, 20, 10)
            setOnClickListener { onClick() }
        }
    }

    private fun buildNotification(): android.app.Notification {
        val channelId = "xboost_floating_panel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(channelId, "Floating Panel", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("XBoost floating panel active")
            .setContentText("Tap the bubble for quick actions")
            .setSmallIcon(R.drawable.ic_xboost_logo)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val NOTIF_ID = 4203
    }
}

package com.xboost.app.core

import android.app.ActivityManager
import android.content.Context
import android.os.Build

/**
 * XBoost runs on everything from a ~1GB-RAM entry-level phone on Android 7
 * up through 12GB+ flagships on the latest release. A single hardcoded polling interval
 * or trim strategy is honest on a flagship and actively counterproductive
 * on a low-end device (the monitoring loop itself becomes a meaningful
 * chunk of the CPU/battery budget). This classifies the *real* device the
 * app is running on so other modules can adapt — no guessing, no fake
 * "optimized for your device" marketing copy.
 */
enum class DeviceTier { LOW, MID, HIGH }

data class DeviceProfile(
    val tier: DeviceTier,
    val isLowRamDevice: Boolean,
    val totalRamMb: Long,
    val sdkInt: Int,
    /** Floor for live-stat polling — never poll faster than this, regardless of Boost mode. */
    val pollingFloorMs: Long
)

object DeviceCompat {

    fun classify(context: Context): DeviceProfile {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        runCatching { am?.getMemoryInfo(memInfo) }
        val totalRamMb = if (memInfo.totalMem > 0) memInfo.totalMem / (1024 * 1024) else 0L
        val lowRamFlag = runCatching { am?.isLowRamDevice == true }.getOrDefault(false)

        val tier = when {
            lowRamFlag || totalRamMb in 1..3071 -> DeviceTier.LOW
            totalRamMb in 3072..5999 -> DeviceTier.MID
            totalRamMb == 0L -> DeviceTier.MID // couldn't read memInfo — assume mid, don't over- or under-promise
            else -> DeviceTier.HIGH
        }

        val pollingFloor = when (tier) {
            DeviceTier.LOW -> 1500L  // budget devices: every extra wakeup competes with the game itself
            DeviceTier.MID -> 800L
            DeviceTier.HIGH -> 500L
        }

        return DeviceProfile(
            tier = tier,
            isLowRamDevice = lowRamFlag || tier == DeviceTier.LOW,
            totalRamMb = totalRamMb,
            sdkInt = Build.VERSION.SDK_INT,
            pollingFloorMs = pollingFloor
        )
    }

    /** Short label shown in Settings so the tuning isn't a black box. */
    fun tierLabel(profile: DeviceProfile): String = when (profile.tier) {
        DeviceTier.LOW -> "Entry-level device — lighter polling & trim to protect performance"
        DeviceTier.MID -> "Mid-range device — balanced defaults"
        DeviceTier.HIGH -> "High-RAM device — fastest polling available"
    }
}
